# 🎯 INTELIGÊNCIA CONVERSACIONAL AVANÇADA

## 🧠 FILOSOFIA CORE

### O Jogo Mental da Venda

**REALIDADE**:
- Você NÃO vende shows. Você vende **transformação**.
- Prefeitura não compra artista. Compra **reeleição** (sucesso político).
- Sindicato não compra festa. Compra **prestígio** (status na região).
- Igreja não compra show gospel. Compra **crescimento** (mais fiéis).

**PRINCÍPIO FUNDAMENTAL**:
> **"People don't buy what you do. They buy why you do it."**

Seu trabalho não é empurrar artista. É **descobrir o que eles realmente querem** e mostrar como você entrega isso.

---

## 🎭 FRAMEWORK: THE CONVERSATION MATRIX

### 3 Níveis de Conversa

**NÍVEL 1: SUPERFICIAL** (Maioria dos concorrentes fica aqui)
```
"Olá, temos artistas disponíveis. Interesse?"
```
❌ Commoditizado, fácil de ignorar

**NÍVEL 2: VALOR** (Onde você precisa chegar)
```
"Vi que o evento anterior teve X problema. 
Temos expertise específica em resolver Y."
```
✅ Relevante, personalizado

**NÍVEL 3: TRANSFORMAÇÃO** (Onde você domina)
```
"Entendo que vocês querem se posicionar como a 
principal festa da região. Baseado em X, Y, Z, 
posso mostrar como fazer isso acontecer."
```
🔥 Irresistível, consultivo

**OBJETIVO**: Sempre operar em Nível 2 mínimo, Nível 3 quando possível.

---

## 💬 DISCOVERY QUESTIONS SUPREMAS

### Por Tipo de Cliente

#### PREFEITURAS (Eventos Públicos)

**SUPERFÍCIE (O que todo mundo pergunta)**:
- "Qual a data do evento?"
- "Qual o orçamento?"
- "Que tipo de artista querem?"

**PROFUNDIDADE (O que você deve perguntar)**:

**1. Motivação Política**:
```
"O que é mais importante para vocês neste evento: 
maximizar público, gerar impacto na imprensa, ou 
atender uma demanda específica da população?"
```
→ **Por quê importa**: Revela se querem QUANTIDADE (público grande) vs. QUALIDADE (satisfação) vs. VISIBILIDADE (mídia)

**2. Sucesso Anterior**:
```
"O que funcionou muito bem no evento do ano passado 
que vocês querem repetir? E o que gostariam que 
fosse diferente?"
```
→ **Por quê importa**: Descobrir padrões de sucesso E dores ocultas

**3. Comparação Regional**:
```
"Vocês acompanham os eventos de cidades vizinhas? 
Há algo que eles fazem que vocês admiram?"
```
→ **Por quê importa**: Revela ambição competitiva (querem ser MELHOR que cidade X)

**4. Stakeholder Político**:
```
"Além de você, quem mais precisa estar feliz com 
o resultado deste evento?"
```
→ **Por quê importa**: Mapear influenciadores (Prefeito? Câmara? População?)

**5. Risco & Medo**:
```
"Qual seria o pior cenário possível para vocês 
neste evento? O que tira o sono?"
```
→ **Por quê importa**: Descobrir a DOR REAL (atraso? Público pequeno? Confusão? Acidente?)

**6. Budget Flexibility**:
```
"Se tivéssemos uma oportunidade excepcional - 
um artista que raramente vem à região - vocês 
teriam flexibilidade para ajustar o orçamento?"
```
→ **Por quê importa**: Saber se budget é FIXO ou tem margem (suplementação orçamentária)

---

#### SINDICATOS RURAIS (Festas de Peão)

**1. Prestígio Regional**:
```
"Qual festa de peão da região vocês consideram 
a referência? O que querem fazer diferente ou 
melhor que ela?"
```
→ **Por quê importa**: Competição entre sindicatos é FEROZ. Use isso.

**2. Público-Alvo**:
```
"Vocês querem atrair principalmente os associados 
e famílias, ou abrir para o público geral da região?"
```
→ **Por quê importa**: Define perfil de artista (familiar vs. festa grande)

**3. Tradição vs. Inovação**:
```
"A festa tem tradições que são inegociáveis? 
Ou vocês estão abertos a fazer algo inédito?"
```
→ **Por quê importa**: Conservadores querem seguro. Inovadores querem destaque.

**4. Retorno Financeiro**:
```
"A festa precisa gerar lucro, empatar, ou o 
objetivo é outro (fortalecer a marca do sindicato)?"
```
→ **Por quê importa**: Define se podem gastar mais (investimento) ou precisam economizar

**5. Legado do Presidente**:
```
"Como presidente, qual legado você quer deixar 
com esta festa? O que as pessoas vão lembrar 
daqui a 5 anos?"
```
→ **Por quê importa**: Ego + ambição = orçamento maior para "fazer história"

---

#### IGREJAS (Eventos Gospel)

**1. Propósito Espiritual**:
```
"Além de celebrar, qual é o objetivo ministerial 
deste evento? Atrair novos fiéis? Fortalecer os 
atuais? Evangelizar a comunidade?"
```
→ **Por quê importa**: Igreja SEMPRE tem propósito além do entretenimento

**2. Perfil da Congregação**:
```
"Qual é o perfil predominante da igreja? 
Mais jovens, famílias, terceira idade?"
```
→ **Por quê importa**: Define tipo de artista (contemporâneo vs. tradicional)

**3. Budget & Doações**:
```
"O orçamento vem de dízimos/ofertas ou vocês 
fazem campanhas específicas para eventos?"
```
→ **Por quê importa**: Saber se precisam "prestar contas" aos membros (transparência)

**4. Testemunho & Transformação**:
```
"Vocês gostariam que os artistas compartilhassem 
testemunhos, ou preferem focar só na ministração 
musical?"
```
→ **Por quê importa**: Revela se querem show vs. experiência espiritual

**5. Parcerias Ministeriais**:
```
"Vocês costumam fazer parcerias com outras igrejas 
para eventos? Ou preferem algo mais intimista?"
```
→ **Por quê importa**: Evento conjunto = budget maior + público maior

---

#### CLUBES (Eventos Sociais)

**1. Identidade do Clube**:
```
"Como vocês definem a identidade do clube? 
Mais família, mais jovem, mais tradicional?"
```
→ **Por quê importa**: Define tom do evento e tipo de artista

**2. Frequência & Engajamento**:
```
"Vocês notam que eventos mensais mantêm o 
engajamento dos sócios, ou seria melhor fazer 
menos eventos porém maiores?"
```
→ **Por quê importa**: Abre oportunidade para VÁRIOS eventos vs. um mega-evento

**3. Receita & Sustainability**:
```
"Os eventos precisam gerar receita (venda de 
convites/consumação) ou são subsidiados pelo clube?"
```
→ **Por quê importa**: Define precificação e tipo de artista

**4. Diferenciação Competitiva**:
```
"O que faz os sócios escolherem o clube de vocês 
ao invés de outros da região?"
```
→ **Por quê importa**: Eventos são parte da proposta de valor

**5. Próxima Geração**:
```
"Vocês têm preocupação em atrair sócios mais 
jovens para renovar a base?"
```
→ **Por quê importa**: Abre porta para artistas mais modernos/jovens

---

## 🎭 OBJEÇÃO HANDLING AVANÇADO

### Framework: F.E.A.R. (Feel, Empathize, Answer, Refocus)

**ESTRUTURA**:
1. **Feel**: "Entendo como você se sente..."
2. **Empathize**: "Outros clientes pensaram o mesmo..."
3. **Answer**: "O que descobrimos foi..."
4. **Refocus**: "Voltando ao que é importante para vocês..."

---

### OBJEÇÃO #1: "Está muito caro"

**❌ RESPOSTA RUIM**:
"Mas a qualidade custa..."
"Podemos negociar..."
"Nosso preço é justo..."

**✅ RESPOSTA SUPREMA**:

**PASSO 1: Separar Preço de Valor**
```
"Entendo a preocupação com o investimento. 
Posso perguntar: quando você diz 'caro', está 
comparando com uma proposta específica que 
recebeu, ou é em relação ao orçamento disponível?"
```

**PASSO 2a: Se comparando com concorrente**
```
"Ótimo! Comparar é importante. Posso perguntar: 
a outra proposta inclui [X, Y, Z que você oferece]? 
Porque nosso valor está em [benefício específico]."
```

**PASSO 2b: Se é orçamento**
```
"Entendo. Vamos trabalhar dentro do orçamento. 
O que é mais importante para vocês: ter o artista 
dos sonhos ou ter a estrutura perfeita? Assim 
podemos priorizar o investimento."
```

**PASSO 3: Reframing**
```
"Pensando no resultado - um evento que gera [X 
benefício], qual seria o custo de NÃO fazer isso 
do jeito certo?"
```

**EXEMPLO REAL**:
```
Prospect: "R$ 380k é muito caro para nós."

Você: "Entendo, R$ 380k é um investimento significativo. 
Posso perguntar: vocês já têm uma referência de valor, 
ou é em relação ao orçamento aprovado?

Prospect: "Nosso orçamento é R$ 300k."

Você: "Perfeito! R$ 300k é um bom orçamento. Deixa eu 
te mostrar como chegamos em R$ 380k:
- Artista Nacional (R$ 200k)
- Estrutura Premium (R$ 120k)
- Produção (R$ 60k)

Duas opções:
1. Artista Regional forte (R$ 80k) + estrutura premium 
   = R$ 260k
2. Artista Nacional + estrutura boa (não premium) 
   = R$ 300k exatos

Qual faz mais sentido para o objetivo de vocês?"
```

---

### OBJEÇÃO #2: "Já trabalhamos com [Concorrente X]"

**❌ RESPOSTA RUIM**:
"Somos melhores que eles..."
"Eles têm problemas de..."
"Dá uma chance pra gente..."

**✅ RESPOSTA SUPREMA**:

```
"Excelente! [Concorrente X] é uma boa produtora. 
Vocês estão satisfeitos com o trabalho deles?"

[Se SIM]
"Que bom! Nesse caso, não quero tirar vocês de 
algo que funciona. Fico à disposição como plano B 
ou para um evento diferente. Posso ficar no radar?"

[Se NÃO / "Mais ou menos"]
"Entendo. O que vocês gostariam que fosse diferente?"

[Escutar atentamente]

"Isso faz total sentido. Deixa eu te contar: 
[Cliente Y] tinha exatamente essa mesma preocupação 
com [problema mencionado]. O que fizemos foi [solução]. 
Resultado: [outcome específico].

Faz sentido explorar como poderíamos fazer algo 
similar para vocês?"
```

**CHAVE**: Nunca atacar concorrente. Sempre **diferenciar sem desmerecer**.

---

### OBJEÇÃO #3: "Preciso pensar / Vou avaliar"

**❌ RESPOSTA RUIM**:
"Ok, quando posso retornar?"
"Sem pressão, me avisa!"

**✅ RESPOSTA SUPREMA**:

```
"Claro, é uma decisão importante mesmo. Posso 
perguntar: o que especificamente você precisa 
avaliar? Assim posso te ajudar com as informações 
certas."

[Escutar]

[Geralmente é 1 de 3 coisas]

1. BUDGET: "Preciso confirmar orçamento"
   → "Entendo. Qual seria o orçamento ideal vs. 
       o que você tem disponível hoje? Assim posso 
       já preparar opções."

2. APROVAÇÃO: "Preciso falar com [decisor superior]"
   → "Perfeito. O que eu poderia fornecer que 
       facilitaria essa conversa? Um resumo executivo? 
       Cases similares?"

3. COMPARAÇÃO: "Quero ver outras propostas"
   → "Faz todo sentido. Posso sugerir: quando for 
       comparar, olhe [critérios X, Y, Z]. São os 
       que mais impactam o resultado. Posso te enviar 
       um checklist?"

[Sempre tentar uma micro-conversão]
"Enquanto você avalia, posso te mandar alguns vídeos 
de eventos similares que fizemos? Ajuda a visualizar."
```

---

### OBJEÇÃO #4: "Não temos budget agora"

**❌ RESPOSTA RUIM**:
"Me avisa quando tiver!"
"Posso fazer mais barato..."

**✅ RESPOSTA SUPREMA**:

```
"Entendo. Deixa eu perguntar: 'não temos agora' 
significa que:
a) O orçamento vem em [mês específico]?
b) Está aguardando aprovação?
c) Não está nos planos para este ano?

[Se A ou B - Há budget futuro]
"Ótimo! Então vamos fazer o seguinte: eu preparo 
tudo agora, bloqueio a data, e quando o orçamento 
liberar já estamos prontos. Assim vocês garantem 
os melhores artistas antes de estarem indisponíveis. 
Faz sentido?"

[Se C - Sem budget mesmo]
"Entendo. Posso fazer diferente: que tal eu te 
ajudar a JUSTIFICAR o orçamento? Preparar um 
business case mostrando o retorno (visibilidade, 
impacto, comparação com cidades vizinhas)? 

Já ajudei [Cidade X] a conseguir aprovar R$ Xk 
mostrando o impacto. Quer que eu faça algo similar?"
```

---

### OBJEÇÃO #5: "Vou fazer uma licitação"

**✅ RESPOSTA SUPREMA**:

```
"Perfeito! Licitação é o caminho certo para 
transparência. Posso te ajudar com o edital?

Já participamos de várias licitações e sei o que 
funciona. Posso sugerir alguns critérios técnicos 
que garantem qualidade sem engessar demais?

[Se aceitar]
→ Ajudar a moldar edital (sem viés óbvio, mas 
  incluindo critérios que você atende bem)

[Independente]
"Quando sair o edital, pode me avisar? Vamos 
participar com certeza."

[Follow-up]
Monitorar DO, participar, preparar proposta killer.
```

---

## 🎨 STORYTELLING PARA VENDAS

### Framework: H.E.R.O. (Hook, Emotion, Resolution, Outcome)

**ESTRUTURA**:
1. **Hook**: Capturar atenção (situação similar ao deles)
2. **Emotion**: Criar conexão emocional (dor/desejo)
3. **Resolution**: Mostrar solução (o que você fez)
4. **Outcome**: Resultado tangível (transformação)

---

### EXEMPLO 1: Para Prefeitura Preocupada com Logística

**HISTÓRIA**:
```
"Deixa eu te contar uma coisa que aconteceu com a 
gente ano passado.

[HOOK]
Estávamos produzindo o réveillon de [Cidade X], 
evento de 30 mil pessoas. Três dias antes, o artista 
principal cancelou. Imagina o desespero do secretário!

[EMOTION]
Ele me ligou às 23h, voz tremendo: 'Victor, se não 
resolver isso, minha carreira política acaba. O 
prefeito vai me demitir.'

[RESOLUTION]
Acionamos nossa rede. Em 18 horas, conseguimos 
[Artista Y], do mesmo nível, por um valor até melhor. 
Reestruturamos tudo: palco, som, cronograma.

[OUTCOME]
Resultado? Evento impecável, pontual, 32 mil pessoas. 
O secretário foi promovido a chefe de gabinete 3 meses 
depois. Ele me disse: 'Vocês não venderam um show, 
salvaram minha carreira.'

[BRIDGE]
É por isso que nosso diferencial não é só ter artistas. 
É ter BACKUP, PLANO B, PLANO C. É dormir tranquilo 
sabendo que se algo der errado, resolvemos."
```

**POR QUÊ FUNCIONA**:
- ✅ Mostra problema similar (empatia)
- ✅ Demonstra capacidade de resolver crise
- ✅ Resultado = benefício deles (carreira salva)
- ✅ Diferenciação clara

---

### EXEMPLO 2: Para Sindicato Rural Competitivo

**HISTÓRIA**:
```
"Posso te contar uma história rápida?

[HOOK]
Sindicato de [Cidade Z] sempre fazia festa de peão 
boa, mas modesta. 15k pessoas, artistas regionais.

[EMOTION]
O presidente me disse: 'A festa de [Cidade Rival] 
é DUAS VEZES maior que a nossa. Nossos associados 
vão pra lá. Isso dói, sabe?'

[RESOLUTION]
Desenhamos uma estratégia de 3 anos:
- Ano 1: Artista nacional médio + estrutura premium
- Ano 2: Headliner + dobrar estrutura  
- Ano 3: Festival de 3 dias

[OUTCOME]
Ano 1: 22k pessoas (+47%)
Ano 2: 38k pessoas (+153% vs. início)
Ano 3: 55k pessoas - MAIOR QUE A RIVAL!

Hoje eles são referência. A rival agora copia ELES.

[BRIDGE]
Não é sobre um evento. É sobre construir LEGADO. 
Você quer que [Seu Sindicato] seja a referência da 
região?"
```

---

### EXEMPLO 3: Para Igreja com Orçamento Apertado

**HISTÓRIA**:
```
"Deixa eu compartilhar algo que mexeu comigo.

[HOOK]
Igreja pequena em [Cidade], 300 membros, orçamento 
de R$ 8 mil para aniversário.

[EMOTION]
A pastora me disse: 'Victor, a gente quer fazer algo 
especial, mas não temos recurso. Toda festa é a mesma 
coisa. Nossos jovens estão desmotivados.'

[RESOLUTION]
Fizemos diferente. Ao invés de 1 artista grande, 
trouxemos 3 artistas menores, criamos momento de 
adoração, testemunho, envolvemos os jovens da igreja 
na produção.

Eles se sentiram PARTE do evento, não só público.

[OUTCOME]
Custo: R$ 7.5k (dentro do budget!)
Resultado: 450 pessoas (igreja lotou!), 12 decisões 
de fé, grupo de jovens cresceu 40% depois.

A pastora chorou. Disse que foi o evento mais 
significativo em 10 anos de ministério.

[BRIDGE]
Grande não é sempre melhor. IMPACTO é melhor. 
Vocês querem quantidade ou transformação?"
```

---

## 🧲 CRIANDO URGÊNCIA (Sem Pressão)

### Técnicas Éticas

**TÉCNICA 1: Scarcity Real**
```
"[Artista X] tem apenas 3 datas livres no segundo 
semestre. Se decidirmos até [data], consigo garantir. 
Depois, ele já estará fechado."
```

**TÉCNICA 2: Competitive Pressure**
```
"Estou conversando com [Cidade Y] também para [mês]. 
Não posso fazer os dois na mesma data. Quem decidir 
primeiro, garante."
```

**TÉCNICA 3: Budget Window**
```
"Seu orçamento foi aprovado para 2026. Se não 
executarmos até [trimestre], corre o risco de 
contingenciamento. Vale garantir agora?"
```

**TÉCNICA 4: Early Bird Value**
```
"Decidindo agora, consigo [benefício extra]: 
- Bloqueio de data sem sinal
- Artista de abertura sem custo
- Upgrade de estrutura

Isso só é possível porque estou planejando com 
antecedência. Depois de [data], não consigo mais."
```

**CHAVE**: Urgência deve ser REAL, não fabricada. Se não é verdade, não use.

---

## 🎯 TÉCNICAS DE FECHAMENTO

### The Assumptive Close

**QUANDO**: Tudo indica que vão fechar, só falta formalizar

**COMO**:
```
"Ótimo! Então vamos assim: eu envio o contrato hoje, 
vocês revisam até sexta, assinamos segunda. Assim já 
bloqueamos [artista] e começamos o planejamento. 
Funciona?"
```

**NÃO perguntar**: "Vocês querem fechar?"  
**PERGUNTAR**: "Como preferem receber o contrato? Email ou presencial?"

---

### The Alternative Close

**QUANDO**: Estão decididos mas indecisos entre opções

**COMO**:
```
"Perfeito! Duas opções então:

Opção A: [Artista X] no sábado = R$ 280k
Opção B: [Artista Y] no domingo = R$ 250k

Ambos são excelentes. Qual faz mais sentido para 
o público de vocês?"
```

**CHAVE**: Não perguntar "sim ou não". Perguntar "A ou B".

---

### The Trial Close

**QUANDO**: Ainda no meio da conversa, testar temperatura

**COMO**:
```
"Baseado no que conversamos até agora, faz sentido 
para vocês, ou tem algo que ainda precisa se 
encaixar melhor?"
```

**OBJETIVO**: Descobrir objeções ocultas ANTES da proposta formal.

---

### The Puppy Dog Close

**QUANDO**: Eles têm dúvida sobre resultado

**COMO**:
```
"Que tal fazermos assim: produzimos um evento menor 
primeiro (R$ 50k), vocês veem nossa execução, e se 
gostar, fazemos o grande (R$ 300k) depois. 

Sem compromisso futuro. Só uma chance de mostrar 
nosso trabalho. Topa?"
```

**ANALOGIA**: Pet shop deixa levar cachorrinho pra casa. Você se apega e compra.

---

## 💎 ADVANCED TACTICS

### Tática 1: The Columbo Reverse

**CONTEXTO**: Reunião acabando, tudo dito

**EXECUÇÃO**:
```
[Levantando para sair]

"Ah, só uma última coisa..."

[Pergunta que revela a REAL objeção]

"Você mencionou que precisa pensar. Mas entre nós: 
se fosse VOCÊ decidindo com seu próprio dinheiro, 
você fecharia? Ou tem algo que te incomoda?"
```

**POR QUÊ FUNCIONA**: Guarda baixa, conversa "entre nós" revela verdade.

---

### Tática 2: The Takeaway

**CONTEXTO**: Eles estão indecistos, arrastando

**EXECUÇÃO**:
```
"Olha, acho que não é o momento certo para vocês. 
Talvez ano que vem faça mais sentido. Vamos manter 
contato?"
```

**REAÇÃO COMUM**: "Não, não! Espera. É que..."

**POR QUÊ FUNCIONA**: Medo de perder oportunidade força decisão.

**⚠️ AVISO**: Só use se realmente estiver ok em perder o deal. Não pode ser blefe.

---

### Tática 3: The Value Stack

**CONTEXTO**: Eles achando caro

**EXECUÇÃO**:
```
"Deixa eu detalhar exatamente o que está incluído:

✅ Artista Nacional [Artista X]: R$ 200k
✅ Estrutura (palco 12x8m, som 40k watts): R$ 80k
✅ Iluminação profissional (150 refletores): R$ 40k
✅ Equipe técnica (20 profissionais): R$ 30k
✅ Seguro responsabilidade civil: R$ 15k
✅ Backup generator: R$ 10k
✅ Gerenciamento de cronograma: R$ 5k

TOTAL: R$ 380k

Se fossem contratar cada item separado, pagaria 
R$ 420k. Nosso pacote é R$ 380k.

Vê o valor agora?"
```

**POR QUÊ FUNCIONA**: Itemizar mostra que não é caro, é JUSTO.

---

### Tática 4: The Social Proof Cascade

**CONTEXTO**: Eles não te conhecem, céticos

**EXECUÇÃO**:
```
"Entendo a cautela. Deixa eu te mostrar quem confia 
na gente:

[NÍVEL 1: Autoridade]
Prefeitura de [Cidade Grande] - 5 anos consecutivos

[NÍVEL 2: Similar]
[Sindicato/Igreja/Clube] igual ao de vocês - evento 
mês passado, 10k pessoas

[NÍVEL 3: Testemunho]
'Melhor decisão que tomamos' - [Nome], [Cargo]

[NÍVEL 4: Mídia]
[Link para matéria em portal local]

Não estão comprando no escuro. Estão comprando 
comprovado."
```

---

## 🎓 LINGUAGEM CORPORAL & TOM

### Presencial

**O QUE FAZER**:
- ✅ Espelhar postura deles (rapport)
- ✅ Contato visual direto
- ✅ Gestos abertos (não cruzar braços)
- ✅ Inclinar ligeiramente para frente (interesse)
- ✅ Pausas estratégicas (deixar eles pensarem)

**O QUE NÃO FAZER**:
- ❌ Falar rápido demais (ansiedade)
- ❌ Mexer muito (nervosismo)
- ❌ Olhar para baixo (insegurança)
- ❌ Encher silêncios (deixe eles processarem)

---

### Telefone/Vídeo

**O QUE FAZER**:
- ✅ Sorrir (eles "ouvem" o sorriso)
- ✅ Tom confiante mas não arrogante
- ✅ Pausas para confirmação ("Faz sentido?")
- ✅ Energia um pouco acima do normal (compensa falta de presença física)

**O QUE NÃO FAZER**:
- ❌ Monólogo (eles desligam)
- ❌ Interromper respostas
- ❌ Tom monocórdico (boring)
- ❌ Background barulhento

---

## 🚀 IMPLEMENTAÇÃO

### SEMANA 1: Treinar Discovery Questions

- Escolher 5 perguntas para cada tipo de cliente
- Praticar em voz alta
- Decorar estrutura (não script)

### SEMANA 2: Objeção Handling

- Listar 10 objeções mais comuns
- Escrever resposta F.E.A.R. para cada
- Praticar com colega/espelho

### SEMANA 3: Storytelling

- Compilar 3 casos de sucesso
- Estruturar em H.E.R.O.
- Memorizar versão curta (2 min)

### SEMANA 4: Role-Play

- Simular call completa
- Gravar e revisar
- Ajustar baseado em feedback

**RESULTADO**: Domínio conversacional em 1 mês! 🎯

---

**CONVERSAS VENDEM. DISCURSOS NÃO.  
DOMINE O DIÁLOGO. DOMINE A VENDA.** 💬🔥
