# ⚔️ COMPETITIVE BATTLECARDS SUPREMAS

## 🎯 FILOSOFIA COMPETITIVA

### Regra de Ouro
> **"Nunca fale MAL do concorrente. Sempre se posicione MELHOR."**

**ERRADO**: "Produtora X é ruim porque..."  
**CERTO**: "Nosso diferencial é [Y], o que significa que..."

---

## 🔍 MAPEAMENTO COMPETITIVO

### Tipos de Concorrentes

**TIER 1: CONCORRENTES DIRETOS** (Produtoras Full-Service)
- Mesmo perfil de serviço
- Mesmo range de budget
- Mesma geografia

**TIER 2: CONCORRENTES PARCIAIS** (Especializados)
- Só estrutura (sem artistas)
- Só artistas (sem produção)
- Só um gênero musical

**TIER 3: CONCORRENTES INDIRETOS** (Alternativos)
- Prefeitura fazendo internamente
- Cliente contratando artista direto
- Agências de publicidade

**TIER 4: CONCORRENTES NÃO-ÓBVIOS** (Substitutos)
- "Não fazer evento" (não-consumo)
- Evento virtual
- Evento menor/simples

---

## ⚔️ BATTLECARD #1: Concorrente de PREÇO BAIXO

### Perfil
- Proposta 30-50% mais barata
- Estrutura básica
- Artistas de menor calibre
- Geralmente novos no mercado ou desesperados

### Suas Forças
- ✅ Preço imbatível
- ✅ Flexibilidade (aceitam qualquer coisa)
- ✅ Urgência (precisam fechar)

### Suas Fraquezas
- ❌ Pouca experiência
- ❌ Sem backup/plano B
- ❌ Estrutura questionável
- ❌ Histórico limitado

---

### ESTRATÉGIA DE COMBATE

#### 1. REFRAME: Preço → Investimento

**ERRADO**:
```
"Eles são baratos porque são ruins."
```

**CERTO**:
```
"A questão não é preço vs. preço. É investimento vs. 
risco. Deixa eu te mostrar o que aconteceu com 
[Cidade X] que escolheu a opção mais barata:

- Show atrasou 2h (público foi embora)
- Som falhou (artista reclamou publicamente)
- Repercussão negativa (prefeito criticado)

O que 'economizaram' em budget, pagaram 10x em 
reputação. Vale o risco?"
```

---

#### 2. VALUE vs. COST

**FRAMEWORK: Custo Total de Propriedade**

```
PROPOSTA BARATA (Concorrente):
• Artista: R$ 80k
• Estrutura: R$ 60k
• Total: R$ 140k

NOSSA PROPOSTA:
• Artista: R$ 150k
• Estrutura: R$ 120k
• Seguro: R$ 15k (ELES NÃO TÊM!)
• Backup: R$ 10k (ELES NÃO TÊM!)
• Gerenciamento: R$ 5k (ELES NÃO INCLUEM!)
• Total: R$ 300k

DIFERENÇA: R$ 160k

MAS O QUE VOCÊ GANHA:
✅ Zero risco de falha técnica
✅ Garantia de pontualidade
✅ Plano B se artista cancelar
✅ Equipe experiente (50+ eventos)
✅ Seguro cobrindo qualquer acidente
✅ Reputação protegida

PERGUNTA: Vale R$ 160k ter CERTEZA que vai dar 
certo vs. TORCER para dar certo?"
```

---

#### 3. SOCIAL PROOF DEVASTADOR

```
"Entendo que o preço é atraente. Posso te mostrar 
algo?

[Mostrar portfolio lado a lado]

CONCORRENTE BARATO:
• Eventos realizados: 5-10
• Porte médio: 2k pessoas
• Referências: ?

SOLIR:
• Eventos realizados: 200+
• Porte médio: 15k pessoas
• Referências: Prefeitura de [A], [B], [C]
                Sindicato de [X], [Y]
                
[Mostrar fotos lado a lado]

Qual evento parece com o que você quer fazer?"
```

---

#### 4. RISK MITIGATION

**OFERECER GARANTIAS QUE CONCORRENTE NÃO PODE**:

```
"Eles oferecem garantia de execução? Porque nós sim:

✅ Garantia de pontualidade (se atrasar, desconto)
✅ Seguro de responsabilidade civil (R$ 1M cobertura)
✅ Plano B documentado (artista backup pré-aprovado)
✅ Equipe técnica certificada
✅ Referências verificáveis (pode ligar)

Se algo der errado com eles, quem assume? 
Conosco, está protegido contratualmente."
```

---

### QUANDO VOCÊ PERDE PARA PREÇO BAIXO

**ACEITAÇÃO**:
```
"Entendo a decisão de vocês. Budget é real.

Posso fazer um pedido? Se QUALQUER coisa der errado 
- técnica, logística, artista - me ligue. Mesmo que 
seja última hora. A gente resolve.

Não quero ver vocês numa situação difícil só por 
causa de preço. Combinado?"
```

**POR QUÊ FAZER ISSO**:
- Mantém relacionamento
- Quando (não se) der problema, você é a solução
- Próximo evento, eles vêm direto pra você

---

## ⚔️ BATTLECARD #2: Concorrente de RELACIONAMENTO ANTIGO

### Perfil
- Trabalham juntos há 3-5+ anos
- Confiança estabelecida
- "Sempre foi assim"
- Difícil de deslocar

### Suas Forças
- ✅ Confiança construída
- ✅ Conhecem processos internos
- ✅ Risco zero (cliente sabe o que esperar)
- ✅ Relacionamento pessoal

### Suas Fraquezas
- ❌ Complacência (relaxam na qualidade)
- ❌ Acomodação (não inovam)
- ❌ Assumem cliente cativo
- ❌ Preço pode estar inflado (sem competição)

---

### ESTRATÉGIA DE COMBATE

#### 1. NÃO ATACAR DIRETAMENTE

**ERRADO**:
```
"Eles estão te explorando há anos!"
"Você merece coisa melhor!"
```

**CERTO**:
```
"É ótimo que vocês têm um parceiro de confiança. 
Relacionamentos de longo prazo são valiosos.

Não quero tomar o lugar deles. Mas posso oferecer 
uma segunda opção? Às vezes ter um plano B fortalece 
até a relação principal."
```

---

#### 2. POSITIONING: Complementar, Não Substituir

**ESTRATÉGIA "FOOT IN THE DOOR"**:

```
"Que tal fazermos assim:

Eles continuam com o evento principal (ex: Réveillon).
Nós fazemos um evento DIFERENTE (ex: Aniversário).

Vocês testam nosso trabalho sem risco, e depois 
decidem se faz sentido ter dois fornecedores ou não.

No mínimo, ter dois dá poder de negociação.
No máximo, vocês descobrem que nosso padrão é 
diferente."
```

---

#### 3. INNOVATION WEDGE (Cunha de Inovação)

**OFERECER ALGO QUE CONCORRENTE ANTIGO NÃO FAZ**:

```
"Eles são ótimos no que fazem. Mas deixa eu te 
perguntar:

- Vocês já pensaram em fazer um festival de 2 dias 
  ao invés de 1 noite?
  
- Já consideraram live streaming para alcançar quem 
  não pode ir presencialmente?
  
- Que tal trazer artistas de gêneros DIFERENTES para 
  ampliar público?

Essas são tendências que estamos vendo explodir. 
[Concorrente] provavelmente não oferece porque sempre 
fizeram do mesmo jeito.

Podemos explorar isso juntos?"
```

---

#### 4. COMPETITIVE BENCHMARK

**MOSTRAR O QUE ESTÃO PERDENDO**:

```
"Vocês sabem quanto [Cidade Vizinha] pagou pelo 
evento deles?

R$ 250k para evento similar ao que vocês pagam R$ 350k.

Não estou dizendo que [Concorrente] está superfaturando. 
Mas quando não há competição, preços tendem a subir 
naturalmente.

Que tal pedir uma proposta nossa E uma deles? 
Vocês comparam maçãs com maçãs. Melhor negócio 
para vocês, e eles são forçados a se atualizar."
```

---

#### 5. PROBLEM AMPLIFICATION (Se houver reclamação)

**SE identificar insatisfação (pesquisa!)**:

```
"Vi que no evento do ano passado houve [problema X]. 
Imagino que deve ter sido frustrante.

Posso perguntar: [Concorrente] apresentou um plano 
para que isso não aconteça de novo?

[Se NÃO]
Porque nós sim. Deixa eu te mostrar..."

[Se SIM]
Ótimo! E eles executaram? Ou foi só conversa?"
```

**CHAVE**: Não inventar problema. Só amplificar o que JÁ existe.

---

### QUANDO VOCÊ PERDE PARA RELACIONAMENTO

**LONG GAME**:
```
"Entendo perfeitamente. Relacionamento é importante.

Posso fazer uma sugestão? Vou continuar mandando 
informações úteis (tendências, ideias, benchmarks) 
sem pressão de venda.

Se um dia vocês quiserem uma segunda opinião ou 
comparação, estarei aqui. Sem compromisso."
```

**DEPOIS**: Nutrir com conteúdo de valor a cada 2-3 meses. Quando relacionamento antigo rachar, você está posicionado.

---

## ⚔️ BATTLECARD #3: Concorrente PREMIUM (Mais Caros que Você)

### Perfil
- Marca forte
- Portfolio impressionante
- Preços altos
- Clientes de prestígio

### Suas Forças
- ✅ Reputação impecável
- ✅ Cases de grande porte
- ✅ Percepção de qualidade superior

### Suas Fraquezas
- ❌ Preço inacessível para muitos
- ❌ Podem ser "overqualified" para eventos menores
- ❌ Menos atenção para clientes menores

---

### ESTRATÉGIA DE COMBATE

#### 1. REFRAME: Elite → Overkill

```
"[Concorrente Premium] é excelente, sem dúvida. 
Eles fazem eventos de R$ 1M+ com perfeição.

A questão é: vocês PRECISAM desse nível para um 
evento de R$ 300k?

É como contratar arquiteto de arranha-céu para 
construir uma casa. Ele faz bem, mas é o fit certo?

Nós somos especialistas em eventos EXATAMENTE do 
tamanho do de vocês. É nosso sweet spot."
```

---

#### 2. VALUE FOR MONEY

```
"Vou ser honesto: eles entregam qualidade top. 
Mas vocês vão pagar 40% a mais por 10% de diferença.

ELES: R$ 420k
NÓS: R$ 300k

Diferença de R$ 120k. 

Pergunta: esse R$ 120k poderia ser usado para:
- Trazer um segundo artista (ampliar lineup)
- Investir em marketing (aumentar público)
- Economizar para próximo evento

Faz mais sentido?"
```

---

#### 3. ATTENTION & CUSTOMIZATION

```
"Eles são grandes. MUITO grandes.

Você será um dos 50 clientes deles no ano.
Você será um dos nossos 15 clientes.

Onde você acha que terá mais atenção?
Onde seu evento será prioridade?

Não é sobre capacidade. É sobre foco."
```

---

### QUANDO VOCÊ PERDE PARA PREMIUM

**GRACEFUL EXIT**:
```
"Parabéns pela decisão! [Concorrente] vai fazer 
um trabalho impecável.

Se vocês quiserem um benchmarking depois (comparar 
resultados, ROI, satisfação), adoraria conversar.

E para eventos futuros, estamos aqui."
```

**VALOR**: Manter relacionamento. Cliente premium hoje pode ser seu amanhã (ou indicar outros).

---

## ⚔️ BATTLECARD #4: "Vamos Fazer Internamente"

### Perfil
- Prefeitura/Organização quer economizar
- Acham que conseguem fazer sozinhos
- Subestimam complexidade

### Riscos Deles
- ❌ Falta de expertise
- ❌ Sem network de artistas
- ❌ Logística complexa
- ❌ Responsabilidade total em caso de problema

---

### ESTRATÉGIA DE COMBATE

#### 1. RISK EDUCATION

```
"Entendo a lógica de economizar. Deixa eu te 
mostrar o que envolve:

LOGÍSTICA:
• Contratar artista (negociar, contrato, rider técnico)
• Estrutura (palco, som, luz, gerador backup)
• Equipe técnica (20+ pessoas coordenadas)
• Segurança (brigada, ambulância, controle de acesso)
• Licenças (ECAD, bombeiros, alvará)
• Seguro (responsabilidade civil)

TEMPO:
• 200+ horas de trabalho (3 meses antes)
• Sua equipe tem essas horas sobrando?

RISCO:
• Se algo falhar, quem é responsável?
• Artista cancela, tem plano B?
• Acidente acontece, está segurado?

Fazendo internamente, vocês economizam R$ 80k.
Se algo der errado, o custo (reputação + lawsuit) 
pode ser R$ 500k+.

Vale o risco?"
```

---

#### 2. HYBRID SOLUTION

```
"Que tal fazermos assim:

VOCÊS: Cuidam da parte operacional simples
       (divulgação, vendas, logística local)
       
NÓS: Cuidamos da parte técnica complexa
     (artista, estrutura, gestão do evento)

Resultado: Vocês economizam 30%, mantêm controle, 
           mas transferem o risco técnico para nós.

Faz mais sentido?"
```

---

#### 3. TIME VALUE OF MONEY

```
"Quanto custa a hora de trabalho da sua equipe?

Se equipe ganha R$ 5k/mês = R$ 25/hora
200 horas = R$ 5.000 em custo de oportunidade

Isso SEM contar:
• Stress
• Curva de aprendizado
• Erros de iniciante

Terceirizar por R$ 80k vs. fazer internamente 
por R$ 5k + 200h de dor de cabeça + risco infinito.

Ainda faz sentido interno?"
```

---

## 🎯 MATRIZ DE POSICIONAMENTO

### Quadrante Competitivo

```
         ALTO PREÇO
              │
    PREMIUM   │   OVERPRICED
    (Conc. A) │   (Evitar)
              │
──────────────┼──────────────── ALTA QUALIDADE
              │
    VALUE     │   LOWCOST
    (VOCÊ)    │   (Conc. B)
              │
         BAIXO PREÇO
```

**SUA POSIÇÃO IDEAL**: VALUE (Alta Qualidade + Preço Justo)

**MESSAGING**:
```
"Não somos os mais baratos (esses geralmente têm problemas).
Não somos os mais caros (você pagaria por nome, não resultado).

Somos a melhor RELAÇÃO custo-benefício.
Qualidade profissional, preço razoável, risco zero."
```

---

## 🛡️ DEFESAS CONTRA ATAQUES

### Se Concorrente Fala Mal de Você

**RESPOSTA CLASSE**:
```
"Interessante que [Concorrente] mencionou isso.

Olha, eu poderia falar sobre eles também, mas não vou.

Prefiro deixar nosso trabalho falar. 

[Mostrar portfolio]

Você julga. Resultado fala mais alto que fofoca."
```

**NEVER**: Entrar em guerra de lama. Sempre high road.

---

## 💎 ADVANCED TACTICS

### Tática 1: Referência Cruzada

**USAR CLIENTES EM COMUM**:
```
"Você conhece [Pessoa X] da [Cidade Y]?

Ano passado eles usaram [Concorrente]. Este ano 
usaram a gente.

Posso te passar o contato dele para você perguntar 
por que mudaram?"
```

**DEVASTADOR**: Cliente que trocou deles para você é prova social máxima.

---

### Tática 2: Competitive Audit

**OFERECER ANÁLISE GRÁTIS**:
```
"Tenho uma ideia: me manda a proposta deles (sem 
valores se quiser), e eu faço uma análise técnica.

Vou te mostrar:
✅ O que está bom
✅ O que está faltando
✅ O que está overspecced

Zero compromisso. Só quero te ajudar a tomar 
decisão informada."
```

**VALOR**: Posiciona você como consultor, não vendedor.

---

### Tática 3: The Trojan Horse

**ENTRAR COMO PARCEIRO DO CONCORRENTE**:
```
"Olha, se vocês já estão confortáveis com [Concorrente], 
beleza.

Mas que tal eles cuidarem da produção, e nós 
fornecemos o artista?

Ou vice-versa?

Assim vocês têm best of both worlds."
```

**DEPOIS**: Uma vez dentro, você prova valor e cresce participação.

---

## 📊 COMPETITIVE INTELLIGENCE GATHERING

### O Que Descobrir Sobre Cada Concorrente

**PORTFOLIO**:
- Quais clientes têm
- Quais perderam (e por quê)
- Porte médio de eventos

**PRICING**:
- Faixa de valores
- Como estruturam propostas
- Onde cortam custos

**WEAKNESSES**:
- Reclamações recorrentes
- Gaps de serviço
- Problemas técnicos

**STRENGTHS**:
- O que fazem melhor
- Por que clientes escolhem eles
- Diferenciais reais

**FONTES**:
- Instagram deles (ver eventos)
- Comentários em posts
- Conversar com ex-clientes
- Networking com fornecedores comuns

---

## 🚀 IMPLEMENTAÇÃO

### CRIAR SUA BIBLIOTECA DE BATTLECARDS

**ESTRUTURA**:
```
CONCORRENTE: [Nome]

QUANDO COMPETEM CONOSCO:
• Tipo de evento: [X, Y, Z]
• Faixa de budget: [R$ X-Y]

FORÇAS DELES:
1. [Força 1]
2. [Força 2]

FRAQUEZAS DELES:
1. [Fraqueza 1]
2. [Fraqueza 2]

NOSSO POSICIONAMENTO:
"[Mensagem-chave diferenciadora]"

OBJEÇÕES COMUNS:
• "[Objeção 1]" → [Resposta]
• "[Objeção 2]" → [Resposta]

CASOS DE VITÓRIA:
• [Cliente A]: Por que ganhamos
• [Cliente B]: O que fizemos diferente

CASOS DE DERROTA:
• [Cliente C]: Por que perdemos
• [Cliente D]: Lição aprendida
```

---

## 💪 MINDSET COMPETITIVO

### Regras de Engajamento

1. **NUNCA** fale mal de concorrente. Sempre respeite.
2. **SEMPRE** se diferencie com FATOS, não opiniões.
3. **FOCO** no cliente, não no concorrente.
4. **COMPETIÇÃO** te torna melhor. Agradeça por ela.
5. **VITÓRIA** com classe. **Derrota** com dignidade.

---

### Frase de Ouro

> **"Não jogue para eles perderem.**  
> **Jogue para VOCÊ ganhar."**

---

**COMPETIÇÃO É INEVITÁVEL.  
VITÓRIA É ESCOLHA.  
ESCOLHA VENCER.** ⚔️🔥
