# 📋 TEMPLATES PRÁTICOS - ACCOUNT RESEARCH

## 🎯 TEMPLATE 1: PLANILHA DE TRACKING DE PROSPECTS

### Google Sheets - Estrutura Completa

**ABA 1: MASTER LIST**

| ID | Nome | Tipo | Cidade | Budget Tier | Score | Status | Próximo Evento | Approach Date | Responsável | Notas |
|----|------|------|--------|-------------|-------|--------|----------------|---------------|-------------|-------|
| 001 | Pref. Caldas Novas | Prefeitura | Caldas Novas | Grande (450k) | 88 | Hot Lead | Réveillon Dez/26 | Jun/26 | Victor | Problema atraso 2025 |
| 002 | Sind. Rural Catalão | Sindicato | Catalão | Grande (300k) | 85 | Hot Lead | EXPO Jul/26 | Mar/26 | Victor | Novo presidente |
| 003 | Igreja Central | Igreja | Goiânia | Pequeno (15k) | 62 | Warm | Aniversário Out/26 | Ago/26 | - | - |

**Fórmula de Score** (automate):
```
=SUM(
  IF(Budget="Grande",40,IF(Budget="Médio",30,IF(Budget="Pequeno",20,10))),
  IF(Timing="0-3 meses",30,IF(Timing="3-6 meses",20,10)),
  IF(Contato="Direto",30,IF(Contato="Via Secretaria",20,10))
)
```

---

**ABA 2: DISCOVERY MATRIX (Template para copiar)**

```
PROSPECT: [Nome]
DATA RESEARCH: [DD/MM/AAAA]
PESQUISADO POR: [Nome]

┌─────────────────────────────────────────┐
│ 1. FIRMOGRAPHIC                         │
├─────────────────────────────────────────┤
│ Tipo: [Prefeitura/Igreja/Sindicato]    │
│ Tamanho: [Pop/Membros/Associados]      │
│ Localização: [Cidade, Distância]        │
│ Freq. Eventos: [Anual/Trimestral]       │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 2. BUDGET INTELLIGENCE                  │
├─────────────────────────────────────────┤
│ Budget Estimado: R$ [valor]             │
│ Fonte: [Transparência/Histórico/Est]    │
│ Tier: [Micro/Pequeno/Médio/Grande]      │
│ Sazonalidade: [Mês de maior gasto]      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 3. HISTORICAL                           │
├─────────────────────────────────────────┤
│ Último Evento: [Data, Artista]          │
│ Público: [Estimativa]                    │
│ Fornecedor: [Nome produtora]             │
│ Resultado: [Sucesso/Problemas]          │
│ Problema Identificado: [Detalhe]        │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 4. DECISION-MAKER                       │
├─────────────────────────────────────────┤
│ Nome: [Nome completo]                    │
│ Cargo: [Título]                          │
│ Email: [email]                           │
│ Telefone: [número]                       │
│ LinkedIn: [URL]                          │
│ Perfil: [Conservador/Inovador/etc]      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 5. TIMING                               │
├─────────────────────────────────────────┤
│ Próximo Evento: [Data]                   │
│ Janela Decisão: [Mês]                    │
│ QUANDO ABORDAR: [Data ideal]             │
│ Urgência: [Alta/Média/Baixa]            │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 6. PAIN POINTS & OPPORTUNITY            │
├─────────────────────────────────────────┤
│ Dor Principal: [Desafio]                 │
│ Oportunidade: [Como resolver]            │
│ Ângulo de Abordagem: [Mensagem-chave]   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ 7. COMPETITIVE                          │
├─────────────────────────────────────────┤
│ Fornecedor Atual: [Nome]                 │
│ Relacionamento: [Forte/Médio/Fraco]     │
│ Switch Probability: [Alta/Média/Baixa]   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ LEAD SCORE: [0-100]                     │
│ • Budget: [0-40]                         │
│ • Timing: [0-30]                         │
│ • Access: [0-30]                         │
│                                          │
│ STATUS: [Hot/Warm/Cold]                 │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ APPROACH STRATEGY                       │
├─────────────────────────────────────────┤
│ 1. [Primeiro passo]                      │
│ 2. [Segundo passo]                       │
│ 3. [Terceiro passo]                      │
│ 4. [Proposta]                            │
│ 5. [Follow-up]                           │
└─────────────────────────────────────────┘
```

---

**ABA 3: HISTÓRICO DE INTERAÇÕES**

| Prospect ID | Data | Canal | Tipo | Notas | Próximo Passo | Data Próximo |
|-------------|------|-------|------|-------|---------------|--------------|
| 001 | 15/03 | Email | Outreach inicial | Enviado intro | Aguardar 3 dias | 18/03 |
| 001 | 18/03 | - | Follow-up automático | Sem resposta | Tentar LinkedIn | 20/03 |
| 001 | 20/03 | LinkedIn | Conexão | Aceitou! | Mensagem DM | 20/03 |
| 001 | 20/03 | LinkedIn DM | Mensagem | Respondeu interesse | Agendar call | 21/03 |

---

**ABA 4: CALENDAR - TIMING MAP**

Visual de quando abordar cada prospect:

| Prospect | Jan | Fev | Mar | Abr | Mai | Jun | Jul | Ago | Set | Out | Nov | Dez |
|----------|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| Caldas Novas | - | - | - | - | - | ✅ABORDAR | - | - | - | - | - | 🎉EVENTO |
| Catalão | - | - | ✅ABORDAR | - | - | - | 🎉EVENTO | - | - | - | - | - |
| Igreja Central | - | - | - | - | - | - | - | ✅ABORDAR | - | 🎉EVENTO | - | - |

**Legenda**:
- ✅ ABORDAR = Janela ideal de prospecção
- 🎉 EVENTO = Data do evento
- 📞 FOLLOW = Follow-up previsto

---

## 🔍 TEMPLATE 2: RESEARCH CHECKLIST RÁPIDO (15 MIN)

### Versão Printável/Checklist

**PROSPECT**: ________________________________

**☐ FASE 1: BÁSICO (3 min)**
- [ ] Tipo identificado (Prefeitura/Igreja/Sindicato/etc)
- [ ] Tamanho (população/membros)
- [ ] Localização e distância

**☐ FASE 2: BUDGET (3 min)**
- [ ] Portal Transparência checado (se prefeitura)
- [ ] OU budget estimado por tamanho/histórico
- [ ] Tier classificado (Micro/Pequeno/Médio/Grande)

**☐ FASE 3: HISTÓRICO (3 min)**
- [ ] Instagram/Facebook checado
- [ ] Último evento identificado (data + artista)
- [ ] Fornecedor anterior descoberto

**☐ FASE 4: DECISOR (3 min)**
- [ ] Nome do decisor encontrado
- [ ] Ao menos 1 contato validado (email OU tel)
- [ ] Perfil básico (LinkedIn OU Instagram)

**☐ FASE 5: TIMING (3 min)**
- [ ] Próximo evento provável identificado
- [ ] Janela de decisão calculada
- [ ] Data ideal de approach definida

**COMPLETION**: ___/5 fases = ___%

**RESULTADO**:
- 5/5 (100%) = EXCELENTE, abordar com confiança
- 4/5 (80%) = BOM, suficiente para começar
- 3/5 (60%) = OK, pode abordar mas com cautela
- <3/5 (<60%) = Pesquisar mais antes de abordar

---

## 💬 TEMPLATE 3: SCRIPTS DE ABORDAGEM BASEADOS EM RESEARCH

### Script 1: Email Inicial - Prefeitura (Com Research)

**ASSUNTO**: Réveillon Caldas Novas 2026 - Execução Perfeita

```
Olá Maria,

Vi que o Réveillon de Caldas Novas vem crescendo ano a ano - parabéns 
pelo trabalho! Notei que em 2025 houve um público excelente, mas alguns 
comentários mencionaram um atraso no início.

Somos especializados em produção de eventos de médio e grande porte 
com foco em cronograma perfeito. Já produzimos réveillons em [Cidade X] 
e [Cidade Y] com pontualidade absoluta e público de 20-30 mil pessoas.

Topa trocar uma ideia de 15 minutos sobre o réveillon 2026? 
Posso compartilhar alguns cases e entender melhor a visão de vocês.

Abs,
[Nome]
Solir Produções
[Tel] | [WhatsApp]
```

**POR QUE FUNCIONA**:
- ✅ Menciona nome dela (personalização)
- ✅ Cita problema específico (research!)
- ✅ Posiciona solução exata (cronograma perfeito)
- ✅ Prova social (outras cidades)
- ✅ Low-commitment ask (15 min)

---

### Script 2: LinkedIn Message - Sindicato Rural (Com Research)

**Após aceitar conexão**:

```
Oi [Nome do Presidente]! 

Parabéns pela EXPO 2024 - vi as fotos, ficou incrível! 
A [Artista X] deve ter arrasado.

Trabalho com produção de festas de peão e rodeios e acompanho 
o trabalho de vocês. Para 2026, se vocês quiserem explorar 
artistas nacionais com budget otimizado, posso ajudar - temos 
acesso direto a [Artista Y] e [Artista Z] por valores bem 
competitivos.

Se fizer sentido, adoraria trocar uma ideia! 🤠

Abs,
[Nome]
```

**POR QUE FUNCIONA**:
- ✅ Casual (tom LinkedIn)
- ✅ Conhecimento do evento deles (research!)
- ✅ Value proposition clara
- ✅ Emoji rural (conexão com nicho)
- ✅ Não-agressivo

---

### Script 3: WhatsApp - Igreja (Com Research)

**Após conseguir número via networking**:

```
Olá Pastor [Nome]! 

Meu nome é [Nome], trabalho com produção de eventos gospel.

Soube pelo irmão [Fulano] que a igreja está planejando o 
aniversário de 20 anos em outubro. Que benção! 🙏

Trabalhamos com artistas gospel de todos os portes e já 
produzimos eventos para [Igreja X] e [Igreja Y] aqui em Goiás.

Se puder ajudar de alguma forma (indicação de artistas, 
orçamento, estrutura), fico à disposição!

Deus abençoe!
[Nome]
[Telefone]
```

**POR QUE FUNCIONA**:
- ✅ Tom gospel (adequado ao cliente)
- ✅ Referência compartilhada (networking)
- ✅ Conhecimento do evento específico (research!)
- ✅ Prova social (outras igrejas)
- ✅ Servir > Vender (abordagem gospel)

---

### Script 4: Ligação - Clube (Com Research)

**Roteiro de Call**:

```
[Secretaria atende]
"Bom dia! Meu nome é [Nome], da Solir Produções. 
Posso falar com o Diretor Social?"

[Transfere para Diretor]

"Oi [Nome do Diretor]! Meu nome é [Nome], trabalho 
com produção de eventos e shows.

Vi no Instagram do clube que vocês fazem eventos 
mensais - muito legal! O último com [Artista] estava 
cheio, né?

Liguei porque trabalhamos com vários artistas de 
sertanejo, pagode e forró que têm feito muito sucesso 
em clubes aqui da região. 

Vocês já têm as atrações definidas para os próximos 
meses ou ainda estão abertos a sugestões?"

[Escutar resposta]

"Perfeito! Posso te mandar por WhatsApp alguns perfis 
de artistas e valores? Daí você avalia se faz sentido 
para vocês."

[Anotar WhatsApp]

"Ótimo, vou mandar hoje mesmo. Obrigado pelo tempo!"
```

**POR QUE FUNCIONA**:
- ✅ Pessoal e direto
- ✅ Conhecimento do clube (research!)
- ✅ Consultivo (não empurra)
- ✅ Próximo passo claro (WhatsApp)

---

## 📊 TEMPLATE 4: ANÁLISE COMPETITIVA PROFUNDA

### Quando usar: Descobrir concorrente forte em um prospect

**ANÁLISE DO FORNECEDOR ATUAL**:

```
CONCORRENTE: [Nome da Produtora]

┌─────────────────────────────────────────┐
│ FORÇAS (O que fazem bem)                │
├─────────────────────────────────────────┤
│ • [Ex: Relacionamento de 5 anos]        │
│ • [Ex: Sempre entregam no prazo]        │
│ • [Ex: Preço competitivo]                │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ FRAQUEZAS (Gaps identificados)          │
├─────────────────────────────────────────┤
│ • [Ex: Problema técnico em 2025]        │
│ • [Ex: Portfolio só sertanejo]           │
│ • [Ex: Sem artistas top tier]            │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ NOSSA DIFERENCIAÇÃO                     │
├─────────────────────────────────────────┤
│ Vs. Força 1: [Como competir]            │
│ • [Ex: Também temos relacionamento      │
│   de longo prazo com outros clientes]   │
│                                          │
│ Vs. Fraqueza 1: [Como explorar]         │
│ • [Ex: Somos especialistas em           │
│   cronograma - nunca atrasamos]         │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ ESTRATÉGIA DE APPROACH                  │
├─────────────────────────────────────────┤
│ Tática: [Flanquear/Substituir/Coexistir]│
│                                          │
│ Se FLANQUEAR:                            │
│ • Oferecer para evento DIFERENTE        │
│ • [Ex: Eles fazem Réveillon, oferecer   │
│   para Aniversário da Cidade]           │
│                                          │
│ Se SUBSTITUIR:                           │
│ • Esperar problema/insatisfação          │
│ • Posicionar como "upgrade"              │
│                                          │
│ Se COEXISTIR:                            │
│ • Parceria (eles produzem, nós artista) │
│ • Divisão de eventos (nós gospel, eles  │
│   sertanejo)                             │
└─────────────────────────────────────────┘
```

---

## 🎯 TEMPLATE 5: QUALIFICAÇÃO GO/NO-GO

### Decision Framework: Vale a pena prospectar?

**PROSPECT**: _______________________________

**✅ GO SIGNALS (Precisa de ao menos 3 para continuar)**:

- [ ] Budget adequado (tier Pequeno ou maior)
- [ ] Evento confirmado ou altamente provável
- [ ] Decisor identificado e acessível
- [ ] Timing favorável (janela de decisão apropriada)
- [ ] Sem contrato exclusivo de longo prazo com concorrente
- [ ] Geografia razoável (<300km ou logística viável)
- [ ] Fit com nosso portfólio de artistas

**🚨 NO-GO SIGNALS (1 já é suficiente para STOP)**:

- [ ] Budget < R$ 5k (não compensa esforço)
- [ ] Evento >12 meses no futuro (muito longe)
- [ ] Decisor inacessível ou desconhecido
- [ ] Concorrente com contrato plurianual
- [ ] Cliente com histórico de não-pagamento
- [ ] Fora de nossa área geográfica (>500km)
- [ ] Requer especialização que não temos

**DECISÃO**:

Total GO Signals: ___/7  
Total NO-GO Signals: ___/7

```
SE GO ≥ 3 E NO-GO = 0: PROSPECTAR ✅
SE GO ≥ 5 E NO-GO ≤ 1: PRIORIZAR 🔥
SE GO < 3 OU NO-GO ≥ 2: DESCARTAR ❌
```

---

## 📞 TEMPLATE 6: DISCOVERY CALL SCRIPT

### Quando conseguir a primeira call com prospect

**ESTRUTURA** (30 min):

```
┌─────────────────────────────────────────┐
│ FASE 1: RAPPORT (5 min)                 │
├─────────────────────────────────────────┤
│ "Obrigado pelo tempo, [Nome]!"          │
│ "Vi que [mencionar algo do research]"   │
│ "Como foi [evento recente]?"            │
│ [Escutar, conectar]                      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ FASE 2: DISCOVERY (15 min)              │
├─────────────────────────────────────────┤
│ PERGUNTAS-CHAVE:                         │
│                                          │
│ 1. Evento:                               │
│ "Qual é o próximo evento que vocês      │
│  estão planejando?"                      │
│                                          │
│ 2. Budget:                               │
│ "Vocês já têm uma faixa de orçamento    │
│  definida?" [Se não souber, sugerir     │
│  faixas: "Algo entre 50-100k?"]         │
│                                          │
│ 3. Timing:                               │
│ "Quando vocês precisam ter tudo         │
│  definido?"                              │
│                                          │
│ 4. Decision Process:                     │
│ "Como funciona o processo de decisão    │
│  aí? Você decide sozinho ou tem que     │
│  passar por alguém?"                     │
│                                          │
│ 5. Current Provider:                     │
│ "Vocês já trabalham com alguma          │
│  produtora ou é a primeira vez?"        │
│                                          │
│ 6. Pain Points:                          │
│ "O que é mais importante para vocês     │
│  em um evento? E o que gostariam que    │
│  fosse diferente do último?"            │
│                                          │
│ 7. Success Criteria:                     │
│ "Como vocês vão saber se o evento       │
│  foi um sucesso?"                        │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ FASE 3: POSICIONAMENTO (5 min)          │
├─────────────────────────────────────────┤
│ "Entendi! Então vocês querem [resumir]" │
│ "Nós temos muita experiência com isso." │
│ "Já fizemos [case similar]..."          │
│ [Compartilhar 1-2 cases relevantes]     │
│                                          │
│ "Baseado no que você falou, consigo     │
│  ver [solução específica]."             │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ FASE 4: NEXT STEPS (5 min)              │
├─────────────────────────────────────────┤
│ "Faz sentido eu montar uma proposta     │
│  mais detalhada?"                        │
│                                          │
│ SE SIM:                                  │
│ "Perfeito! Vou preparar e envio até     │
│  [data]. Aí agendamos outra call para   │
│  discutir."                              │
│                                          │
│ SE "PRECISO PENSAR":                     │
│ "Sem problema! O que mais você precisa  │
│  saber para decidir se faz sentido?"    │
│                                          │
│ SE "JÁ TEMOS FORNECEDOR":                │
│ "Entendo! Vocês estão felizes com eles? │
│  [Se não] O que vocês gostariam que     │
│  fosse diferente?"                       │
│  "Posso ficar como plano B ou para      │
│  outro evento?"                          │
└─────────────────────────────────────────┘
```

**APÓS A CALL**:

- [ ] Atualizar CRM com todas as notas
- [ ] Enviar email de agradecimento
- [ ] Se proposta: Enviar em até 48h
- [ ] Agendar follow-up

---

## 💎 TEMPLATE 7: PROPOSTA BASEADA EM RESEARCH

### Estrutura de Proposta Personalizada

```
┌─────────────────────────────────────────┐
│ PROPOSTA COMERCIAL                      │
│ [Nome do Cliente]                        │
│ [Evento Específico] - [Data]            │
└─────────────────────────────────────────┘

1. CONTEXTO
──────────────────────────────────────────
[Resumir o que descobriu no research]

"Entendemos que o Réveillon de Caldas Novas 
é um evento de grande importância para a 
cidade, atraindo mais de 25 mil pessoas 
anualmente. 

Notamos que o evento de 2025 foi um sucesso 
de público, mas houve desafios logísticos que 
impactaram o cronograma. Nossa proposta foca 
em garantir execução perfeita."

2. NOSSA SOLUÇÃO
──────────────────────────────────────────
[Baseado nos pain points identificados]

• Gestão de Cronograma com Timeline Militar
  (garantia de pontualidade)
  
• Artistas de Primeira Linha com Track Record
  Comprovado
  
• Estrutura Técnica Premium (som, luz, palco)

• Equipe de Produção Dedicada 24/7

3. ESCOPO DETALHADO
──────────────────────────────────────────
[Customizar baseado no que fizeram antes]

DIA 31/12/2026:
• 19h00: Abertura oficial (PONTUAL)
• 19h30-21h: Artista Regional [Nome]
• 21h30-23h: Artista Nacional [Nome]
• 23h00: Countdown
• 00h15-02h: Show Principal [Nome]

4. INVESTIMENTO
──────────────────────────────────────────
[Baseado no budget descoberto]

PACOTE COMPLETO: R$ 380.000

Inclui:
• 3 Artistas (regional + nacional + top)
• Estrutura completa (palco, som, luz)
• Equipe de produção
• Seguro de responsabilidade civil
• Gestão de cronograma

CONDIÇÕES:
• 30% na assinatura
• 40% 30 dias antes
• 30% no dia do evento

5. POR QUE SOLIR?
──────────────────────────────────────────
[Cases similares ao deles]

✅ Réveillon [Cidade X] 2024: 30k pessoas,
   início PONTUAL, satisfação 98%
   
✅ Aniversário [Cidade Y] 2025: 15k pessoas,
   evento sem intercorrências
   
✅ 15 anos de experiência em eventos públicos

6. PRÓXIMOS PASSOS
──────────────────────────────────────────
1. Aprovação desta proposta
2. Assinatura de contrato
3. Kickoff de planejamento
4. Execução perfeita!

Validade: 15 dias

[Assinatura]
[Contatos]
```

---

## 🚀 IMPLEMENTAÇÃO DOS TEMPLATES

### SEMANA 1: Setup
- Copiar templates para Google Sheets
- Customizar com sua marca
- Testar com 1 prospect

### SEMANA 2: Scale
- Usar templates em 5 prospects
- Ajustar baseado em feedback
- Otimizar

### SEMANA 3: Automate
- Criar snippets no Gmail (templates de email)
- Salvar scripts de call
- Documentar best practices

---

**ESTES TEMPLATES SÃO SEU ARSENAL.  
USE-OS. CUSTOMIZE-OS. DOMINE-OS.** 🎯💎
