# 🔍 ACCOUNT RESEARCH SUPREMO - PRODUÇÃO ARTÍSTICA

## 🎯 CONTEXTO & OBJETIVOS

### Sua Realidade
**Empresa**: Produção Artística (Intermediação de Artistas)  
**Range de Serviço**: R$ 5.000 (artistas locais) → R$ 500.000+ (Jorge e Mateus, Alok, Péricles, Anita)  
**Clientes Principais**:
- 🏛️ **Prefeituras** (eventos públicos - aniversário cidade, festas juninas, réveillon)
- 🎪 **Festas Locais** (igrejas, sindicatos rurais, carnaval, casamentos, 15 anos, clubes)

### Objetivo do Account Research
**DESCOBRIR** antes de abordar:
1. Quanto eles TÊM de budget (faixa: micro/pequeno/médio/grande)
2. Quem DECIDE a contratação (nome, cargo, contato)
3. O que já FIZERAM antes (histórico de eventos e artistas)
4. QUANDO vão contratar (timing, sazonalidade)
5. Com QUEM trabalham agora (fornecedores atuais, concorrentes)
6. PORQUÊ contratam (motivação: tradição, política, demanda do público)

---

## 📋 FRAMEWORK: THE DISCOVERY MATRIX

Para cada prospect, preencher esta matriz ANTES do primeiro contato:

```
┌─────────────────────────────────────────────────────────┐
│ DISCOVERY MATRIX - [Nome do Prospect]                  │
├─────────────────────────────────────────────────────────┤
│ FIRMOGRAPHIC (Quem são)                                │
│ • Tipo: [Prefeitura/Igreja/Sindicato/Clube/etc]        │
│ • Tamanho: [População/Membros/Associados]              │
│ • Localização: [Cidade, distância de Goiânia]          │
│ • Frequência de Eventos: [Anual/Trimestral/Único]      │
├─────────────────────────────────────────────────────────┤
│ BUDGET INTELLIGENCE (Quanto têm)                       │
│ • Budget Estimado: R$ [faixa]                          │
│ • Fonte: [Transparência/Histórico/Estimativa]          │
│ • Sazonalidade: [Mês/Período de maior gasto]           │
│ • Tier: [Micro<10k / Pequeno 10-50k / Médio 50-200k /  │
│          Grande>200k]                                   │
├─────────────────────────────────────────────────────────┤
│ HISTORICAL (O que fizeram)                             │
│ • Último Evento: [Data, Artista, Público]              │
│ • Eventos Recorrentes: [Lista anual]                   │
│ • Artistas Contratados: [Perfil: local/regional/nac]   │
│ • Fornecedor Anterior: [Quem produziu]                 │
│ • Resultado: [Sucesso/Problemas/Reclamações]           │
├─────────────────────────────────────────────────────────┤
│ DECISION-MAKER (Quem decide)                           │
│ • Nome: [Nome completo]                                 │
│ • Cargo: [Título oficial]                               │
│ • Contato: [Email, Tel, LinkedIn, WhatsApp]            │
│ • Influenciadores: [Quem mais opina]                   │
│ • Perfil: [Conservador/Inovador, Idade, Background]    │
├─────────────────────────────────────────────────────────┤
│ TIMING (Quando abordar)                                │
│ • Próximo Evento: [Data prevista]                      │
│ • Janela de Decisão: [Mês que decide]                  │
│ • Ciclo de Planejamento: [Quando planeja]              │
│ • Urgência: [Alta/Média/Baixa]                         │
├─────────────────────────────────────────────────────────┤
│ PAIN POINTS (Dores e necessidades)                     │
│ • Desafio Principal: [Ex: orçamento apertado]          │
│ • Reclamações Identificadas: [Do evento anterior]      │
│ • Oportunidade: [O que podemos resolver]               │
├─────────────────────────────────────────────────────────┤
│ COMPETITIVE (Concorrência)                             │
│ • Fornecedor Atual: [Nome]                             │
│ • Relacionamento: [Forte/Fraco]                        │
│ • Switching Probability: [Alta/Média/Baixa]            │
└─────────────────────────────────────────────────────────┘
```

---

## 🏛️ RESEARCH WORKFLOW: PREFEITURAS

### PASSO 1: Identificação Inicial

**Fontes**:
- Lista completa de municípios: IBGE
- Prefeituras por população: Wikipedia
- Agenda de aniversários: Calendários cívicos estaduais

**Busca**:
```
web_search: "prefeituras Goiás população 20000 50000"
web_search: "aniversário cidade Goiás 2026 datas"
web_search: "calendário eventos culturais Goiás"
```

**Criar Lista Base**:
| Prefeitura | População | Aniversário | Distância GO | Prioridade |
|------------|-----------|-------------|--------------|------------|
| Caldas Novas | 100k | Maio | 139km | ALTA |
| Anápolis | 391k | Julho | 55km | ALTA |
| Rio Verde | 235k | Agosto | 220km | MÉDIA |

---

### PASSO 2: Budget Intelligence (Portal da Transparência)

**CRITICAL: Este é o OURO da pesquisa!**

#### 2A. Acessar Portal da Transparência Municipal

**URL Típica**: 
```
transparencia.prefeitura[cidade].go.gov.br
OU
[cidade].go.gov.br/transparencia
```

**Se não encontrar portal específico**:
```
web_search: "portal transparência prefeitura [cidade]"
web_search: "[cidade] lei de acesso à informação"
```

#### 2B. Navegar até Despesas

**Caminho Padrão**:
```
Portal da Transparência
→ Receitas e Despesas
→ Despesas por Função
→ Função: 13 - CULTURA
→ Subfunção: 392 - Difusão Cultural
```

**EXTRAIR**:
1. **Orçamento Total Cultura 2026** (LOA aprovada)
2. **Subfunção "Festividades e Eventos"**
3. **Executado até agora** (quanto já gastaram)
4. **Disponível** (quanto ainda têm)

#### 2C. Descobrir Contratos Anteriores

**Caminho**:
```
Portal → Contratos → Buscar: "evento" OU "show" OU "artista" OU "estrutura"
```

**EXTRAIR**:
| Data | Fornecedor | Objeto | Valor | Artista (se mencionar) |
|------|------------|--------|-------|------------------------|
| 2025 | Produtora X | Show Réveillon | R$ 200k | [Artista Y] |
| 2024 | Produtora Z | Aniversário | R$ 150k | [Artista W] |

**O QUE ISSO REVELA**:
- ✅ **Budget Real**: Não é estimativa, é quanto GASTARAM de fato
- ✅ **Concorrentes Ativos**: Quem já trabalhou com eles
- ✅ **Faixa de Artistas**: Local (R$ 20k) vs. Nacional (R$ 200k+)
- ✅ **Recorrência**: Anual? Só esporádico?
- ✅ **Timing**: Quando costumam contratar (mês do empenho)

#### 2D. Análise de Empenhos (Advanced)

**Caminho**:
```
Portal → Empenhos → Função: Cultura → Últimos 12 meses
```

**O QUE BUSCAR**:
- Empenhos abertos = Dinheiro já reservado
- Fornecedor beneficiário = Com quem contrataram
- Data do empenho = Quanto tempo antes do evento eles decidem

**EXEMPLO REAL**:
```
Empenho nº 12345
Data: 15/03/2025
Favorecido: PRODUTORA ABC LTDA
Valor: R$ 180.000,00
Histórico: "CONTRATAÇÃO SHOW ARTÍSTICO RÉVEILLON 2025"
```

**INSIGHTS**:
- ✅ Eles decidem em MARÇO para evento de DEZEMBRO (9 meses antes!)
- ✅ Budget de R$ 180k = Artista médio/grande
- ✅ Produtora ABC é o fornecedor atual (concorrente direto)

---

### PASSO 3: Historical Event Research

**Objetivo**: Descobrir O QUE já fizeram e COMO foi.

#### 3A. Buscar Eventos Passados

**Fontes**:
- Site oficial da prefeitura (notícias/agenda)
- Facebook/Instagram da prefeitura
- Portais de notícias locais
- YouTube (vídeos de eventos)

**Busca**:
```
web_search: "prefeitura [cidade] eventos 2024 2025"
web_search: "aniversário [cidade] 2024 programação"
web_search: "réveillon [cidade] 2024 shows"
web_search: "[cidade] festa junina 2024 atrações"
```

#### 3B. Identificar Artistas Contratados

**MÉTODO 1: Notícias**:
```
"Prefeitura de Caldas Novas anuncia shows do aniversário da cidade:
Dia 15 - Artista A (sertanejo)
Dia 16 - Artista B (pagode)  
Dia 17 - Artista C (forró)"
```

**MÉTODO 2: Redes Sociais**:
- Posts da prefeitura divulgando lineup
- Stories de bastidores
- Fotos marcadas com @ da prefeitura

**MÉTODO 3: Artistas**:
```
web_search: "[artista famoso] agenda shows 2024 [cidade]"
Instagram do artista: Ver posts sobre show em [cidade]
```

#### 3C. Avaliar Resultado (Sucesso vs. Problema)

**SINAIS DE SUCESSO**:
- ✅ Muitas curtidas/comentários positivos
- ✅ Público grande (fotos aéreas)
- ✅ Nota de agradecimento da prefeitura
- ✅ Imprensa local cobriu positivamente

**SINAIS DE PROBLEMA**:
- 🚨 Comentários negativos ("som ruim", "atrasou")
- 🚨 Reclamações sobre estrutura
- 🚨 Público pequeno (fotos vazias)
- 🚨 Críticas do prefeito/oposição

**OURO: Reclamações = Sua Oportunidade!**

Se encontrar: "Evento de 2024 teve problemas de som e atraso"
→ Seu ângulo: "Vi que houve desafios técnicos no ano passado. Nossa especialidade é exatamente garantir execução perfeita..."

---

### PASSO 4: Decision-Maker Discovery

**Objetivo**: NOME, CARGO, CONTATO do decisor.

#### 4A. Identificar Cargo Responsável

**Estrutura Típica de Prefeitura**:
```
PREFEITO
├─ Secretaria de Cultura (decide eventos culturais)
│  ├─ Secretário(a) de Cultura [DECISOR PRINCIPAL]
│  ├─ Coordenador de Eventos [OPERACIONAL]
│  └─ Assessor de Comunicação [INFLUENCIADOR]
├─ Secretaria de Turismo (às vezes cuida de eventos)
└─ Gabinete do Prefeito (eventos muito grandes)
```

**Para eventos > R$ 300k**: Prefeito aprova  
**Para eventos R$ 50k-300k**: Secretário decide  
**Para eventos < R$ 50k**: Coordenador decide

#### 4B. Encontrar o Nome

**MÉTODO 1: Site Oficial**
```
web_search: "site:prefeitura[cidade].go.gov.br secretário cultura"
web_search: "organograma prefeitura [cidade]"
```

Geralmente em: "Secretarias" ou "Quem é Quem"

**MÉTODO 2: Diário Oficial**
```
web_search: "nomeação secretário cultura [cidade] 2024"
web_search: "decreto secretário [cidade]"
```

Secretários são nomeados por decreto publicado no DO.

**MÉTODO 3: Notícias Locais**
```
web_search: "[cidade] secretário cultura nome"
web_search: "entrevista secretário cultura [cidade]"
```

Imprensa local sempre cita nomes.

**MÉTODO 4: Redes Sociais da Prefeitura**
```
Ver posts: Quem aparece nas fotos oficiais?
Ver assinatura: "Secretaria de Cultura - [Nome]"
Stories: Quem fala em nome da secretaria?
```

#### 4C. Encontrar Contatos

**EMAIL**:

**Padrão 1**: nome.sobrenome@prefeitura[cidade].go.gov.br  
**Padrão 2**: cultura@prefeitura[cidade].go.gov.br  
**Padrão 3**: secretario.cultura@[cidade].go.gov.br  
**Padrão 4**: gabinete.cultura@[cidade].go.gov.br

**Como validar**: Enviar email teste ou buscar em documentos oficiais

**TELEFONE**:

Geralmente no site oficial:
```
Prefeitura → Secretarias → Cultura → Contatos
```

Ou ligar na central e pedir transferência:
```
"Alô, bom dia! Preciso falar com a Secretaria de Cultura, 
pode me transferir por favor?"
```

**LINKEDIN**:
```
Buscar: "[Nome] [Cidade]" no LinkedIn
Filtrar: "Government Administration"
```

Secretários costumam ter perfil (networking político).

**WHATSAPP**:

Mais difícil, mas possível:
- Grupos locais de WhatsApp (comerciantes, empresários)
- Networking via conhecidos em comum
- Assessores compartilham informalmente

#### 4D. Perfil do Decisor (Stalking Ético)

**LINKEDIN**:
- Background: Veio da iniciativa privada? Carreira pública?
- Conexões: Quem ele conhece? (possíveis referências)
- Posts: O que compartilha? (valores, interesses)

**FACEBOOK/INSTAGRAM**:
- Estilo: Formal ou casual?
- Interesses: Música, esportes, causas?
- Engajamento: Responde comentários? Ativo?

**NOTÍCIAS**:
```
web_search: "[nome secretário] entrevista"
web_search: "[nome] [cidade] declaração"
```

Entrevistas revelam:
- Prioridades ("Vamos investir em...")
- Estilo de comunicação
- Desafios que enfrenta

**POR QUE ISSO IMPORTA**:
- Secretário jovem e ativo no Instagram → Abordar via DM casual
- Secretário tradicional e formal → Email institucional
- Secretário que prioriza "cultura local" → Enfatizar artistas regionais
- Secretário que quer "destaque nacional" → Enfatizar grandes nomes

---

### PASSO 5: Timing Intelligence

**Objetivo**: QUANDO abordar para maximizar chance de sucesso.

#### 5A. Ciclo de Planejamento

**EVENTOS ANUAIS FIXOS** (Aniversário, Réveillon, São João):

**Timeline típica**:
```
6 MESES ANTES: Planejamento inicial (definir se vai ter)
4-5 MESES ANTES: Aprovação de orçamento (câmara vota)
3-4 MESES ANTES: Abertura de licitação OU contratação direta
2 MESES ANTES: Contratação de artistas/produtora
1 MÊS ANTES: Divulgação pública (lineup)
```

**JANELA DE OPORTUNIDADE**: 3-5 meses antes do evento

**EXEMPLO**:
- Evento: Aniversário da cidade em JUNHO
- Abordar: JANEIRO-FEVEREIRO (4-5 meses antes)
- NÃO abordar em MAIO (tarde demais!)

#### 5B. Ciclo Orçamentário

**JAN-MAR**: 
- ✅ Budget aprovado, dinheiro disponível
- ✅ Melhor época para eventos Q2-Q3
- 🎯 AÇÃO: Prospectar eventos abril-setembro

**ABR-JUN**:
- ⚠️ Meio do ano, eventos em execução
- 🎯 AÇÃO: Nutrir relacionamento para ano seguinte

**JUL-AGO**:
- ✅ Planejar eventos Q4 (réveillon, festas fim de ano)
- 🎯 AÇÃO: Prospectar eventos outubro-dezembro

**SET-OUT**:
- ⚠️ Eleições em anos pares (prefeituras param)
- 🎯 AÇÃO: Se não é ano eleitoral, ok. Se é, esperar novembro.

**NOV-DEZ**:
- ✅ Novo orçamento sendo aprovado
- 🎯 AÇÃO: Assim que LOA aprovar, SER O PRIMEIRO!

#### 5C. Trigger Events (Gatilhos de Timing)

**GATILHOS POLÍTICOS**:
- ✅ Novo prefeito eleito → Quer "deixar marca"
- ✅ Novo secretário nomeado → Quer "mostrar trabalho"
- ✅ Ano de eleição → Eventos aumentam (promoção)

**GATILHOS DE BUDGET**:
- ✅ Orçamento aprovado → Têm dinheiro agora
- ✅ Repasse federal/estadual → Budget extra inesperado
- ✅ Fim do ano → "Gastou pouco, precisa executar"

**GATILHOS DE EVENTO**:
- ✅ Evento anterior foi sucesso → Vão repetir (aumentar budget)
- ✅ Evento anterior fracassou → Procuram novo fornecedor
- ✅ Cidade vizinha fez grande evento → "Queremos também!"

**GATILHOS NEGATIVOS** (NÃO abordar):
- 🚨 Mês de eleição (out em anos pares)
- 🚨 Escândalo político na prefeitura
- 🚨 Corte de orçamento anunciado
- 🚨 Luto oficial declarado

---

## 🎪 RESEARCH WORKFLOW: FESTAS LOCAIS

### Segmentação por Tipo

#### TIPO 1: Igrejas (Eventos Gospel)

**Budget Típico**: R$ 5k-30k  
**Frequência**: Anual (aniversário igreja, celebrações)  
**Decisor**: Pastor/Padre + Conselho  

**Research**:

**1. Identificar Igrejas Grandes**:
```
web_search: "maiores igrejas evangélicas [cidade]"
web_search: "igreja [denominação] [cidade] membros"
web_search: "paróquia católica [cidade] eventos"
```

Priorizar: >500 membros = maior budget

**2. Histórico de Eventos**:
```
Facebook da igreja → Eventos passados
Instagram → #aniversário[igreja] #celebração
YouTube → Vídeos de eventos (ver se teve show)
```

**3. Descobrir Budget**:
- Igreja evangelical grande: R$ 15k-30k
- Igreja católica (paróquia): R$ 10k-20k
- Igreja pequena: R$ 5k-10k

**Fonte**: Perguntar discretamente a fornecedores locais (som, luz) que já trabalharam lá.

**4. Decisor**:
- **Pastor** (evangélica) ou **Padre** (católica)
- **Conselho Administrativo** (às vezes precisa aprovação)

Contato: Site da igreja, ligar na secretaria.

**5. Timing**:
- Aniversário da igreja (data fixa anual)
- Celebrações especiais (Páscoa, Natal - mas geralmente sem show)
- Congressos/Encontros (várias igrejas juntas)

---

#### TIPO 2: Sindicatos Rurais (Festas de Peão)

**Budget Típico**: R$ 50k-500k  
**Frequência**: Anual (mesma época todo ano)  
**Decisor**: Presidente do Sindicato + Diretoria  

**Research**:

**1. Listar Sindicatos**:
```
web_search: "sindicatos rurais Goiás lista"
web_search: "festa de peão [cidade] sindicato"
```

**Fonte oficial**: Sistema FAEG (Federação de Agricultura de GO)
- Site: sistemafaeg.com.br/faeg/sindicatos

**2. Descobrir Tamanho**:
- Número de associados (site ou notícias)
- Faturamento (se disponível em transparência)
- Tamanho da festa anterior (público estimado)

**Regra**: Mais associados = Maior festa = Maior budget

**3. Histórico de Festas**:
```
web_search: "festa de peão [sindicato] 2024 artistas"
Instagram: @festadopeao[cidade] ou @sindicatorural[cidade]
Facebook: Eventos → Ver anos anteriores
```

**EXTRAIR**:
- Quantos dias de festa
- Artistas de cada noite (perfil: regional vs. nacional)
- Público estimado (notícias geralmente citam)

**4. Estimar Budget por Artista**:

**Lineup 2024: Exemplo Hipotético**
- Dia 1: Artista Regional X → R$ 15k-25k
- Dia 2: Artista Nacional Y → R$ 100k-200k
- Dia 3: Artista TOP Z → R$ 300k-500k

**Budget Total Shows**: R$ 415k-725k  
**+ Estrutura** (palco, som, luz): R$ 150k-300k  
**= Total Evento**: R$ 565k-1.025M

**5. Decisor**:
- **Presidente do Sindicato** (nome no site)
- **Diretoria** (aprovação coletiva às vezes)
- **Comissão de Festa** (executam, mas presidente decide)

**Contato**:
```
web_search: "sindicato rural [cidade] contato telefone"
```

Geralmente: presidencia@sindicatorural[cidade].com.br

**6. Timing**:
- Festas de peão: Geralmente JUL-SET (alta temporada)
- Planejamento: 4-6 meses antes (JAN-ABR para festa em AGO)

---

#### TIPO 3: Clubes (Eventos Sociais)

**Budget Típico**: R$ 10k-80k  
**Frequência**: Mensal ou Trimestral  
**Decisor**: Presidente do Clube + Diretoria Social  

**Research**:

**1. Identificar Clubes Ativos**:
```
web_search: "clubes sociais [cidade]"
web_search: "clube [nome] eventos [cidade]"
```

Tipos: Clubes de campo, clubes sociais, associações, grêmios.

**2. Tamanho**:
- Número de sócios (site ou ligar)
- Estrutura física (grande = mais eventos)

**3. Histórico**:
Instagram/Facebook do clube:
- Frequência de eventos (mensal? trimestral?)
- Tipo de eventos (bailes, festas temáticas, shows)
- Artistas contratados (perfil: bandas locais? DJs? Shows?)

**4. Budget**:
- Clube pequeno (<500 sócios): R$ 10k-20k
- Clube médio (500-2000): R$ 20k-50k
- Clube grande (>2000): R$ 50k-100k

**5. Decisor**:
- **Presidente** (principal)
- **Diretor Social** (operacional, decide artistas)

Contato: Site do clube ou ligar na secretaria.

**6. Timing**:
- Alta temporada: Carnaval, Festas Juninas, Réveillon
- Eventos mensais: Último sábado do mês (padrão comum)

---

#### TIPO 4: Carnaval (Blocos e Desfiles)

**Budget Típico**: R$ 20k-200k  
**Frequência**: Anual (fevereiro/março)  
**Decisor**: Organizador do Bloco / Prefeitura (se oficial)  

**Research**:

**1. Identificar Blocos**:
```
web_search: "blocos carnaval [cidade] 2024"
Instagram: #carnaval[cidade] #bloco[nome]
```

**2. Tamanho**:
- Bloco de rua pequeno: R$ 10k-30k
- Bloco grande: R$ 50k-100k
- Carnaval oficial (prefeitura): R$ 200k-1M+

**3. Histórico**:
- Artistas de anos anteriores
- Público (fotos aéreas)

**4. Decisor**:
- Blocos independentes: Organizador (geralmente pessoa física ou coletivo)
- Carnaval oficial: Secretaria de Cultura da prefeitura

**5. Timing**:
- Planejamento: OUT-NOV (4 meses antes)
- Contratação: NOV-DEZ
- Evento: FEV-MAR

---

#### TIPO 5: Casamentos e 15 Anos (Eventos Privados)

**Budget Típico**: R$ 5k-50k  
**Frequência**: Único  
**Decisor**: Família (pais ou noivos)  

**Research** (diferente - não é prospecção ativa, é INBOUND):

**1. Não prospectar ativamente** (low-ROI)

**2. Estratégia de Inbound**:
- Site otimizado para "banda casamento [cidade]"
- Instagram com depoimentos de casamentos
- Parceria com buffets, fotógrafos, cerimonialistas (eles indicam)
- Google Ads local

**3. Qualificação Rápida**:
Quando alguém contatar:
- Budget? (direto: "Nossos pacotes começam em R$ X")
- Data? (checar disponibilidade)
- Estilo? (banda ao vivo, DJ, mix)

**4. Decisor**:
- Quem liga/manda mensagem = Decisor
- Geralmente: Mãe (15 anos) ou Noiva (casamento)

---

## 🎯 BUDGET TIER CLASSIFICATION

### Sistema de Classificação por Budget

**TIER 1: MICRO** (R$ 5k-15k)
- **Clientes**: Igrejas pequenas, clubes locais, eventos privados
- **Artistas**: Bandas locais, DJs, duplas regionais
- **Approach**: Direto, informal, rápido
- **Margem**: Baixa (10-15%)
- **Volume**: Alto (muitos eventos pequenos)

**TIER 2: PEQUENO** (R$ 15k-50k)
- **Clientes**: Igrejas grandes, clubes médios, eventos rurais pequenos
- **Artistas**: Regionais conhecidos, bandas consagradas localmente
- **Approach**: Profissional, proposta simples
- **Margem**: Média (15-20%)
- **Volume**: Médio

**TIER 3: MÉDIO** (R$ 50k-200k)
- **Clientes**: Prefeituras pequenas/médias, sindicatos rurais, clubes grandes
- **Artistas**: Nacionais médios, sertanejos regionais famosos
- **Approach**: Consultivo, proposta detalhada
- **Margem**: Boa (20-25%)
- **Volume**: Baixo-Médio

**TIER 4: GRANDE** (R$ 200k-500k)
- **Clientes**: Prefeituras médias/grandes, festas de peão grandes
- **Artistas**: Nacionais top (Jorge e Mateus, Péricles, etc.)
- **Approach**: ABM, relacionamento profundo
- **Margem**: Muito Boa (25-30%)
- **Volume**: Baixo (deals raros mas grandes)

**TIER 5: MEGA** (>R$ 500k)
- **Clientes**: Capitais, eventos estaduais, grandes festivais
- **Artistas**: Top tier (Alok, Anita, headliners)
- **Approach**: ABM premium, múltiplos stakeholders
- **Margem**: Excelente (30%+)
- **Volume**: Muito baixo (1-2 por ano se conseguir)

---

## 🔬 ADVANCED RESEARCH TECHNIQUES

### Técnica 1: Social Listening Profundo

**Objetivo**: Capturar intenção de compra em tempo real.

**MONITORAR**:

**Facebook - Grupos Locais**:
```
Grupos: "Eventos [Cidade]", "Shows [Região]", "Grupo [Cidade]"
Buscar posts: "alguém conhece banda", "indicação DJ", "preciso artista"
```

**Instagram - Hashtags**:
```
#Evento[Cidade] #Show[Cidade] #Festa[Local]
Ver stories de eventos acontecendo
Comentar oferecendo ajuda
```

**Twitter/X - Menções**:
```
Buscar: "[cidade] show" OU "[organização] evento"
Responder oferecendo serviço
```

---

### Técnica 2: Competitor Reverse Engineering

**Objetivo**: Descobrir clientes da concorrência para abordar.

**MÉTODO**:

**1. Identificar Produtoras Concorrentes**:
```
web_search: "produtoras eventos [região]"
web_search: "agência shows [estado]"
```

**2. Stalking de Instagram**:
- Seguir Instagram delas
- Ver posts de eventos que fizeram
- Identificar clientes (geralmente marcam ou mencionam)

**3. Análise de Comentários**:
Posts de concorrentes → Comentários:
- Positivos: "Ficou lindo!" (cliente satisfeito = difícil roubar)
- Negativos: "Poderia ser melhor" (oportunidade!)

**4. Listar Clientes**:
Criar planilha:
| Cliente | Concorrente | Último Evento | Satisfação | Oportunidade |
|---------|-------------|---------------|------------|--------------|
| Pref. X | Concorrente A | 2024 | Baixa (comentários negativos) | ALTA |

**5. Abordar Estrategicamente**:
NÃO: "Somos melhores que Concorrente A"
SIM: "Vi o evento de vocês em 2024. Temos expertise em [gap específico que eles tiveram]."

---

### Técnica 3: Artist Backtracking

**Objetivo**: Descobrir quem contrata artista X para abordar com artista Y similar.

**MÉTODO**:

**1. Escolher Artista Benchmark**:
Exemplo: "Artista Regional Z faz muito show em Goiás"

**2. Descobrir Agenda Dele**:
```
Instagram do artista: Ver posts de shows
web_search: "[artista] agenda 2024"
Stories: Mostram bastidores em cada cidade
```

**3. Identificar Contratantes**:
Artista posta: "Show em [Cidade] hoje!"
→ Quem contratou? (geralmente marca: @prefeitura[cidade])

**4. Criar Lista de Prospects**:
"Prefeituras que contrataram Artista Z":
- Caldas Novas
- Anápolis
- Mineiros
- ...

**5. Approach com Artista Similar**:
"Vi que vocês contrataram [Artista Z] ano passado. Temos [Artista W] que é do mesmo estilo e está disponível para [data]. Interesse?"

---

### Técnica 4: Seasonal Pattern Analysis

**Objetivo**: Prever quando vão contratar baseado em padrões históricos.

**MÉTODO**:

**1. Mapear Eventos Anuais**:
Para cada cliente tier 1, mapear:
| Prefeitura | Jan | Fev | Mar | Abr | Mai | Jun | Jul | Ago | Set | Out | Nov | Dez |
|------------|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|-----|
| Caldas Novas | - | Carnaval | - | - | Aniv | S.João | - | - | - | - | - | Rév |

**2. Identificar Janela de Decisão**:
Evento em JUNHO → Decisão em FEVEREIRO (4 meses antes)

**3. Criar Calendário de Prospecção**:
```
JANEIRO: Prospectar eventos Maio-Junho
FEVEREIRO: Prospectar eventos Junho-Julho  
MARÇO: Prospectar eventos Julho-Agosto
...
AGOSTO: Prospectar eventos Dezembro-Janeiro
```

**4. Automação**:
Google Calendar com lembretes:
- "JAN: Abordar Pref. X sobre aniversário em MAIO"
- "FEV: Abordar Sindicato Y sobre festa em JUN"

---

## 📊 RESEARCH EFFICIENCY HACKS

### Hack 1: Template de Pesquisa Rápida (15 min por prospect)

**CHECKLIST RÁPIDO**:

**MIN 0-3: Firmographic**
- [ ] Tipo de cliente
- [ ] Tamanho (população/membros)
- [ ] Localização

**MIN 3-6: Budget**
- [ ] Portal da Transparência (se prefeitura)
- [ ] OU estimativa por tamanho

**MIN 6-9: Historical**
- [ ] Buscar Instagram/Facebook
- [ ] Ver 3 últimos eventos

**MIN 9-12: Decision-Maker**
- [ ] Buscar nome do decisor
- [ ] Encontrar 1 contato (email OU telefone)

**MIN 12-15: Timing**
- [ ] Próximo evento provável
- [ ] Quando abordar

**OUTPUT**: Discovery Matrix 80% preenchida em 15 min!

---

### Hack 2: Batch Research (Escala)

Ao invés de: Pesquisar 1 prospect por vez
FAZER: Pesquisar 10 prospects em lote

**PROCESSO**:

**LOTE 1: Firmographic (30 min para 10)**
- Abrir 10 abas
- Preencher básico de todos

**LOTE 2: Budget (1h para 10)**
- Acessar Portal Transparência de todos
- Extrair orçamentos

**LOTE 3: Historical (30 min para 10)**
- Instagram de todos
- Ver eventos rápidos

**LOTE 4: Decision-Makers (1h para 10)**
- Buscar nomes de todos
- Compilar contatos

**TOTAL**: 3h para 10 prospects = 18 min cada (vs. 30-40 min individual)

---

### Hack 3: Scorecard de Priorização

Depois de research, RANKEAR prospects:

**SCORING**:
```
Budget (0-40 pontos):
- Micro (<15k): 10
- Pequeno (15-50k): 20
- Médio (50-200k): 30
- Grande (>200k): 40

Timing (0-30 pontos):
- Evento confirmado próximos 3 meses: 30
- Evento provável 3-6 meses: 20
- Evento >6 meses: 10

Acessibilidade (0-30 pontos):
- Contato direto encontrado: 30
- Encontrado via secretaria: 20
- Difícil acesso: 10

TOTAL: 0-100
```

**PRIORIZAÇÃO**:
- 80-100: HOT (abordar HOJE)
- 60-79: WARM (abordar esta semana)
- 40-59: COLD (nurture, abordar mês que vem)
- <40: DESCONSIDERAR (não vale esforço)

---

## 🎯 EXEMPLO COMPLETO: RESEARCH DE PREFEITURA

**TARGET**: Prefeitura de Caldas Novas - Réveillon 2026

**DISCOVERY MATRIX PREENCHIDA**:

```
┌─────────────────────────────────────────────────────────┐
│ CALDAS NOVAS - RÉVEILLON 2026                          │
├─────────────────────────────────────────────────────────┤
│ FIRMOGRAPHIC                                            │
│ • Tipo: Prefeitura (evento público)                    │
│ • População: 100.284 habitantes (IBGE 2024)            │
│ • Localização: 139km de Goiânia (1h30)                 │
│ • Frequência: Réveillon ANUAL (todo fim de ano)        │
├─────────────────────────────────────────────────────────┤
│ BUDGET INTELLIGENCE                                     │
│ • Budget Total Cultura 2026: R$ 2.500.000              │
│   (Fonte: Portal Transparência, LOA aprovada dez/2025) │
│ • Subfunção Eventos: R$ 1.200.000                      │
│ • Réveillon Específico: R$ 450.000 (empenho 2025)      │
│ • Executado até março: R$ 180.000                      │
│ • DISPONÍVEL: R$ 270.000 (ainda pode aumentar)         │
│ • Tier: GRANDE (>R$ 200k)                              │
├─────────────────────────────────────────────────────────┤
│ HISTORICAL                                              │
│ • Réveillon 2024/2025:                                  │
│   - Artista Principal: [Nacional Médio] - R$ 180k      │
│   - Artista Regional: [Local] - R$ 40k                 │
│   - Público: ~25.000 pessoas                            │
│   - Fornecedor: Produtora XYZ Ltda                      │
│ • Resultado: POSITIVO (muitos elogios nas redes)       │
│ • Problema identificado: Atraso de 1h no início        │
│   (Fonte: Comentários Facebook)                         │
│ • Eventos Recorrentes:                                  │
│   - Aniversário (Maio): R$ 300k                         │
│   - São João (Junho): R$ 200k                           │
│   - Réveillon (Dez): R$ 450k                            │
├─────────────────────────────────────────────────────────┤
│ DECISION-MAKER                                          │
│ • Nome: Maria Silva Santos                              │
│ • Cargo: Secretária Municipal de Cultura e Turismo     │
│ • Tempo no cargo: 3 anos (nomeada em 2023)             │
│ • Contatos:                                             │
│   - Email: maria.silva@caldasnovas.go.gov.br            │
│   - Tel Secretaria: (64) 3453-XXXX                      │
│   - LinkedIn: linkedin.com/in/mariasilvasantos          │
│   - Instagram: @mariaseccultura (ativo, responde DM)    │
│ • Influenciadores:                                      │
│   - Prefeito João Costa (aprova budget >300k)           │
│   - Coord. Eventos: Pedro Alves (executa)               │
│ • Perfil:                                               │
│   - 42 anos, formada em Gestão Pública (UFG)            │
│   - Estilo: Profissional mas acessível                  │
│   - Valores: "Eventos que gerem impacto no turismo"     │
│   - Ativa em redes (posta bastante sobre eventos)       │
├─────────────────────────────────────────────────────────┤
│ TIMING                                                  │
│ • Próximo Evento: Réveillon 2026/2027 (31/dez)         │
│ • Janela de Decisão: JULHO-AGOSTO 2026                 │
│   (baseado em empenho anterior em agosto/2025)          │
│ • Ciclo de Planejamento:                                │
│   - Mai: Planejamento inicial                           │
│   - Jun-Jul: Aprovação prévia orçamento                 │
│   - Ago: Licitação OU contratação direta               │
│   - Set: Fechamento com artistas                        │
│ • Urgência: MÉDIA (ainda temos 4 meses)                │
│ • MELHOR TIMING PARA ABORDAR: JUNHO 2026               │
├─────────────────────────────────────────────────────────┤
│ PAIN POINTS                                             │
│ • Desafio 2025: Evento atrasou 1h (problema logístico) │
│ • Pressão: Réveillon é evento de maior visibilidade    │
│ • Necessidade: Execução perfeita, sem atrasos           │
│ • Oportunidade: Enfatizar nosso histórico de           │
│   pontualidade e gestão de cronograma                   │
├─────────────────────────────────────────────────────────┤
│ COMPETITIVE                                             │
│ • Fornecedor Atual: Produtora XYZ Ltda (3 anos)        │
│ • Relacionamento: FORTE (3 anos consecutivos)           │
│ • Mas: Tiveram problema em 2025 (atraso)               │
│ • Switching Probability: MÉDIA                          │
│   - Pro switch: Problema recente                        │
│   - Contra switch: Relacionamento longo                 │
│ • Estratégia: NÃO atacar direto. Posicionar como       │
│   alternativa/backup ou para evento diferente (Aniv)    │
├─────────────────────────────────────────────────────────┤
│ LEAD SCORE: 88/100                                     │
│ • Budget: 40 (Grande)                                   │
│ • Timing: 28 (3-4 meses, bom momento)                   │
│ • Access: 20 (Contatos encontrados, secretária ativa)  │
│                                                         │
│ STATUS: HOT LEAD - ABORDAR EM JUNHO                    │
│                                                         │
│ APPROACH STRATEGY:                                      │
│ 1. Email para Maria (mencionando problema 2025)        │
│ 2. LinkedIn connection (networking)                     │
│ 3. Oferecer call de 15min "troca de ideias"            │
│ 4. Posicionar: "Especialistas em cronograma perfeito"  │
│ 5. Se interesse: Proposta formal detalhada             │
└─────────────────────────────────────────────────────────┘
```

**TEMPO TOTAL DE RESEARCH**: ~45 minutos  
**RESULTADO**: Prospect COMPLETAMENTE mapeado, pronto para abordagem cirúrgica!

---

## 💎 GOLDEN RULES DO ACCOUNT RESEARCH

1. **Research ANTES de Abordar** - NUNCA contatar sem preencher ao menos 60% da Discovery Matrix

2. **Portal da Transparência É OURO** - Para prefeituras, investir 15-20 min aqui vale MUITO a pena

3. **Histórico > Estimativa** - Sempre buscar o que FIZERAM antes, não o que você ACHA que fazem

4. **Decisor Certo > Canal Perfeito** - Melhor ter email do decisor certo do que WhatsApp da secretária

5. **Timing = 50% do Sucesso** - Melhor prospect na hora errada = perda de tempo

6. **Problemas = Oportunidades** - Reclamação de evento anterior é SUA porta de entrada

7. **Batch > Individual** - Pesquisar em lote é 2x mais eficiente

8. **Score & Priorize** - Não trate todos iguais. 20% dos prospects = 80% do revenue.

9. **Document Everything** - CRM ou planilha. Memória falha, dados não.

10. **Update Constantly** - Research não é one-time. Atualizar a cada interação.

---

## 🚀 IMPLEMENTAÇÃO IMEDIATA

### SEMANA 1: Setup
- Criar template Discovery Matrix (Google Sheets)
- Listar 20 prospects tier 1 (prefeituras grandes)
- Configurar lembretes de timing no calendário

### SEMANA 2: Research em Lote
- Batch research de 10 prospects
- Preencher Discovery Matrix
- Rankear por score

### SEMANA 3: Primeiras Abordagens
- Top 3 Hot Leads → Abordar
- Documentar resultados
- Ajustar approach baseado em feedback

### SEMANA 4: Scale
- Research de mais 10
- Continuar abordagens
- Otimizar processo

**META**: 30 prospects bem-pesquisados/mês = 1-2 deals fechados = R$ 50k-200k revenue/mês

---

**ESTE É O RESEARCH SUPREMO.  
CONHECIMENTO É PODER.  
PODER É FECHAMENTO.** 🎯💎🔥
