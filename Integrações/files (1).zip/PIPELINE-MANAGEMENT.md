# 📊 PIPELINE MANAGEMENT & FORECASTING

## 🎯 FILOSOFIA DO PIPELINE

### O Pipeline É Seu Combustível

**REALIDADE**:
```
Pipeline vazio HOJE = Fome em 90 dias
Pipeline cheio HOJE = Fartura em 90 dias
```

**PRINCÍPIO**:
> **"Você não gerencia vendas. Você gerencia PROBABILIDADES."**

Cada deal tem % de chance. Sua missão: **maximizar probabilidades** e **acelerar velocidade**.

---

## 📈 ANATOMIA DO PIPELINE

### Stages do Funil (Produção Artística)

```
┌─────────────────────────────────────┐
│ STAGE 1: NEW LEAD                  │  100% dos leads
│ Identificado, não contatado         │  Conversão: 100% → 60%
│ Tempo: 0 dias                       │  Prob. Fechamento: 5%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 2: CONTACTED                 │  60% dos leads
│ Primeiro contato feito              │  Conversão: 60% → 30%
│ Tempo: 1-3 dias                     │  Prob. Fechamento: 10%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 3: QUALIFIED                 │  30% dos leads
│ BANT confirmado, fit validado       │  Conversão: 30% → 20%
│ Tempo: 3-7 dias                     │  Prob. Fechamento: 25%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 4: MEETING SCHEDULED         │  20% dos leads
│ Call/reunião agendada               │  Conversão: 20% → 15%
│ Tempo: 7-14 dias                    │  Prob. Fechamento: 40%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 5: PROPOSAL SENT             │  15% dos leads
│ Proposta formal enviada             │  Conversão: 15% → 8%
│ Tempo: 14-30 dias                   │  Prob. Fechamento: 60%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 6: NEGOTIATION               │  8% dos leads
│ Discutindo termos/ajustes           │  Conversão: 8% → 5%
│ Tempo: 30-45 dias                   │  Prob. Fechamento: 75%
└─────────────────────────────────────┘
           ↓
┌─────────────────────────────────────┐
│ STAGE 7: CLOSED WON / LOST         │  5% won, 95% lost
│ Deal fechado ou perdido             │  
│ Tempo: 45-60 dias (ciclo médio)     │  
└─────────────────────────────────────┘
```

**MÉTRICAS-CHAVE**:
- Conversão global: **5% (100 leads → 5 fechados)**
- Ciclo de vendas médio: **45-60 dias**
- Ticket médio: **R$ 100k-150k**

---

## 🎯 LEAD SCORING AVANÇADO

### Sistema de Pontuação (0-100)

#### CATEGORIA 1: FIRMOGRAPHIC (0-30 pontos)

**BUDGET TIER** (0-15):
- Tier Mega (>R$ 500k): 15 pts
- Tier Grande (R$ 200-500k): 12 pts
- Tier Médio (R$ 50-200k): 9 pts
- Tier Pequeno (R$ 15-50k): 6 pts
- Tier Micro (<R$ 15k): 3 pts

**TIPO DE CLIENTE** (0-15):
- Prefeitura grande (>100k hab): 15 pts
- Sindicato Rural (festa anual): 12 pts
- Prefeitura média (30-100k): 10 pts
- Clube/Igreja grande: 8 pts
- Outros: 5 pts

---

#### CATEGORIA 2: BEHAVIORAL (0-40 pontos)

**ENGAGEMENT** (0-20):
- Respondeu < 24h: 20 pts
- Respondeu 24-72h: 15 pts
- Respondeu > 72h: 10 pts
- Não respondeu: 0 pts

**DECISION STAGE** (0-20):
- Budget aprovado, data definida: 20 pts
- Planejando, sem data: 15 pts
- Explorando opções: 10 pts
- "Só pesquisando": 5 pts

---

#### CATEGORIA 3: TIMING (0-30 pontos)

**URGÊNCIA** (0-15):
- Evento em 0-3 meses: 15 pts
- Evento em 3-6 meses: 12 pts
- Evento em 6-12 meses: 8 pts
- Evento >12 meses: 3 pts

**SAZONALIDADE** (0-15):
- Alta temporada (Jun-Ago, Dez): 15 pts
- Média temporada (Mar-Mai, Set-Nov): 10 pts
- Baixa temporada (Jan-Fev): 5 pts

---

### CLASSIFICAÇÃO POR SCORE

```
90-100: 🔥 HOT - Abordar HOJE
70-89:  🌡️ WARM - Abordar esta semana
50-69:  ❄️ COLD - Nutrir, abordar mês que vem
<50:    🗑️ TRASH - Desqualificar ou nurture longo prazo
```

**EXEMPLO PRÁTICO**:

```
PROSPECT: Prefeitura de Caldas Novas - Réveillon 2026

FIRMOGRAPHIC:
• Budget: R$ 450k (Tier Grande) = 12 pts
• Tipo: Prefeitura grande = 15 pts
SUBTOTAL: 27/30

BEHAVIORAL:
• Engagement: Respondeu em 12h = 20 pts
• Decision: Budget aprovado, data definida = 20 pts
SUBTOTAL: 40/40

TIMING:
• Urgência: Evento em 4 meses (ago) = 12 pts
• Sazonalidade: Alta (dez) = 15 pts
SUBTOTAL: 27/30

SCORE TOTAL: 94/100 = 🔥 HOT LEAD
```

---

## 📊 PIPELINE METRICS DASHBOARD

### Métricas Essenciais (Acompanhar Semanalmente)

**VOLUME**:
```
• Total Leads no Pipeline: ___
• New Leads (esta semana): ___
• Qualified Leads: ___
• Deals em Proposta: ___
• Deals em Negociação: ___
```

**VALOR**:
```
• Valor Total Pipeline: R$ ___
• Valor Weighted (probabilidade ajustada): R$ ___
• Ticket Médio: R$ ___
• Maior Deal: R$ ___
```

**CONVERSÃO**:
```
• Taxa Lead → Qualified: ___%
• Taxa Qualified → Proposta: ___%
• Taxa Proposta → Fechamento: ___%
• Taxa Global (Lead → Fechamento): ___%
```

**VELOCIDADE**:
```
• Tempo Médio no Stage 1: ___ dias
• Tempo Médio no Stage 2: ___ dias
• Ciclo de Venda Médio: ___ dias
• Deals Travados (>60 dias): ___
```

**FORECAST**:
```
• Deals Esperados (Este Mês): ___
• Valor Esperado (Este Mês): R$ ___
• Confidence Level: ___%
• Deals Esperados (Próximo Trimestre): ___
```

---

## 🎯 WEIGHTED PIPELINE (Valor Ponderado)

### Fórmula

```
Weighted Value = Valor do Deal × Probabilidade de Fechamento
```

**EXEMPLO**:

```
PIPELINE NOMINAL:
Deal A: R$ 300k (Stage: Proposta) = R$ 300k
Deal B: R$ 200k (Stage: Negociação) = R$ 200k
Deal C: R$ 150k (Stage: Qualified) = R$ 150k
TOTAL NOMINAL: R$ 650k

PIPELINE WEIGHTED:
Deal A: R$ 300k × 60% = R$ 180k
Deal B: R$ 200k × 75% = R$ 150k
Deal C: R$ 150k × 25% = R$ 37.5k
TOTAL WEIGHTED: R$ 367.5k

FORECAST REALISTA: R$ 367.5k (não R$ 650k!)
```

**BENEFÍCIO**: Previsão muito mais precisa.

---

## 🚀 ACELERADORES DE PIPELINE

### Como Mover Deals Mais Rápido

#### ACELERADOR #1: Multi-Threading

**PROBLEMA**: Dependência de 1 pessoa = gargalo

**SOLUÇÃO**: Cultivar múltiplos stakeholders

```
ANTES:
Você ↔ Secretário de Cultura
(Se ele sair, você perde tudo)

DEPOIS:
Você ↔ Secretário de Cultura (decisor)
      ↔ Coordenador de Eventos (operacional)
      ↔ Assessor do Prefeito (influenciador)
      ↔ Presidente da Câmara (aprovador budget)

(Se um sair, outros mantêm você conectado)
```

**COMO FAZER**:
```
"[Secretário], para garantir que tudo saia perfeito, 
seria bom eu conhecer quem vai executar no dia a dia. 
Quem seria a melhor pessoa da sua equipe para discutir 
detalhes técnicos?"
```

---

#### ACELERADOR #2: Criar Urgência Legítima

**ESCASSEZ REAL**:
```
"[Artista X] tem apenas 2 datas livres em dezembro. 
Outra prefeitura está analisando a mesma data. 
Para garantir, precisaria de sinal até sexta."
```

**DEADLINE EXTERNO**:
```
"O orçamento de 2026 fecha em [data]. Se aprovarmos 
agora, entra. Se passar, vai para 2027."
```

**CONSEQUÊNCIA DE ATRASO**:
```
"Quanto mais esperamos, mais artistas ficam 
indisponíveis. Em agosto, teremos 20 opções. 
Em outubro, teremos 5."
```

---

#### ACELERADOR #3: Remover Fricção

**IDENTIFICAR BLOQUEIOS**:
```
"O que está impedindo você de aprovar hoje?"

RESPOSTAS COMUNS:
• "Preciso da aprovação do prefeito"
   → "Posso preparar um resumo executivo para ele?"
   
• "Preciso comparar outras propostas"
   → "Posso te enviar um checklist de comparação?"
   
• "Não tenho certeza se o budget aguenta"
   → "Posso mostrar opções em 3 faixas de preço?"
```

**SEMPRE**: Oferecer solução para cada bloqueio.

---

#### ACELERADOR #4: Próximo Passo Sempre Definido

**NUNCA TERMINAR REUNIÃO SEM NEXT STEP**:

```
❌ ERRADO:
"Beleza, então pensa e me avisa!"

✅ CERTO:
"Ótimo! Então vamos assim:
1. Eu envio a proposta até quarta
2. Você revisa até sexta
3. Agendamos call segunda às 10h para discutir
Funciona?"
```

**MICRO-COMMITMENTS**: Pequenos sims levam ao sim grande.

---

## 🛑 SINAIS DE ALERTA (Deal em Risco)

### Red Flags para Monitorar

**🚨 SINAL 1: Ghosting**
- Não responde emails há >7 dias
- Não atende ligações
- Cancelou reunião sem reagendar

**AÇÃO**: 
```
Email de "breakup":
"[Nome], percebo que não é o momento certo. 
Vou arquivar este projeto. Se mudar, me avisa!"

(Muitas vezes eles respondem imediatamente)
```

---

**🚨 SINAL 2: Perguntas de Preço Repetidas**
- Pede desconto múltiplas vezes
- Compara preço com concorrente constantemente
- Foca só em custo, não em valor

**AÇÃO**:
```
"[Nome], sinto que o investimento é a principal 
preocupação. Deixa eu ser direto: conseguimos 
trabalhar com R$ [X]? Se não, melhor sermos 
honestos agora."

(Forçar decisão: dentro ou fora?)
```

---

**🚨 SINAL 3: Decision Timeline Keeps Moving**
- "Decidimos semana que vem" → 3 semanas depois: "Mais uma semana"
- Sem urgência real
- Não há consequência de não decidir

**AÇÃO**:
```
"[Nome], percebo que a decisão está sendo 
postergada. Posso perguntar: há algo bloqueando 
internamente que eu possa ajudar a resolver? 
Ou seria melhor revisitarmos isso no futuro?"

(Descobrir bloqueio real ou desqualificar)
```

---

**🚨 SINAL 4: New Stakeholder Introduced Late**
- Semana antes de fechar: "Ah, precisa passar pelo [Cargo X]"
- Aparece alguém novo que não estava no processo

**AÇÃO**:
```
"Sem problema! Quando posso apresentar para 
[Novo Stakeholder]? Preciso garantir que ele 
também está alinhado."

(Incluir novo decisor imediatamente)
```

---

## 📈 FORECASTING AVANÇADO

### Método: 3 Scenarios

**SCENARIO 1: CONSERVADOR (70% Confidence)**
```
Incluir apenas:
• Deals em Stage 6 (Negotiation) = 75% prob.
• Deals em Stage 5 (Proposal) com histórico positivo = 50% prob.

EXEMPLO:
Deal A: R$ 300k × 75% = R$ 225k
Deal B: R$ 200k × 50% = R$ 100k
TOTAL: R$ 325k

"Temos 70% de chance de fechar PELO MENOS R$ 325k"
```

---

**SCENARIO 2: REALISTA (50% Confidence)**
```
Incluir:
• Stage 6: 75% prob.
• Stage 5: 60% prob.
• Stage 4: 30% prob.

EXEMPLO:
Deal A: R$ 300k × 75% = R$ 225k
Deal B: R$ 200k × 60% = R$ 120k
Deal C: R$ 150k × 30% = R$ 45k
TOTAL: R$ 390k

"Expectativa realista: R$ 390k"
```

---

**SCENARIO 3: OTIMISTA (30% Confidence)**
```
Incluir tudo:
• Stage 6: 75%
• Stage 5: 60%
• Stage 4: 40%
• Stage 3: 15%

EXEMPLO:
[Deals anteriores] + Deal D: R$ 100k × 15% = R$ 15k
TOTAL: R$ 405k

"No melhor cenário: R$ 405k"
```

---

### RANGE FORECAST

**APRESENTAR ASSIM**:
```
FORECAST MARÇO 2026:

Conservador: R$ 325k (70% confiança)
Realista:    R$ 390k (50% confiança)
Otimista:    R$ 405k (30% confiança)

RECOMENDAÇÃO: Planejar para R$ 325k, 
              torcer por R$ 390k,
              sonhar com R$ 405k.
```

---

## 🎯 PIPELINE HYGIENE

### Rotinas de Limpeza

**SEMANAL** (30 min toda sexta):
```
☐ Atualizar status de todos os deals ativos
☐ Mover deals entre stages (quando aplicável)
☐ Adicionar notas de últimas interações
☐ Definir próxima ação para cada deal
☐ Identificar deals travados (>30 dias no mesmo stage)
```

**MENSAL** (1h última sexta do mês):
```
☐ Revisar deals "Cold" - Manter ou desqualificar?
☐ Analisar deals perdidos - Por quê? Padrão?
☐ Calcular métricas (conversão, velocidade, ticket)
☐ Forecast próximo mês
☐ Ajustar estratégia baseado em dados
```

**TRIMESTRAL** (2h):
```
☐ Deep dive em pipeline health
☐ Identificar gargalos
☐ Revisar ICP (estamos mirando certo?)
☐ Auditar lead sources (quais trazem melhores leads?)
☐ Treinar/ajustar processos
```

---

## 💡 DEAL RESCUE TACTICS

### Quando Deal Está Morrendo

**TÁTICA 1: The Reset**
```
"[Nome], sinto que perdemos o momentum. 
Podemos recomeçar? 

O que você REALMENTE precisa deste evento?
Esquece propostas, orçamentos. Se fosse perfeito, 
como seria?"

(Volta ao basics, re-descoberta)
```

---

**TÁTICA 2: The Pivot**
```
"Percebi que o réveillon pode não ser o melhor 
fit agora. Mas e o aniversário da cidade em maio? 

Orçamento menor, menos pressão, teste nosso trabalho."

(Propor deal alternativo, mais fácil)
```

---

**TÁTICA 3: The Pause**
```
"Que tal pausarmos este projeto por 30 dias? 
Sem pressão, sem follow-up.

Se fizer sentido revisitar, você me procura. 
Combinado?"

(Tirar pressão pode reativar interesse)
```

---

## 📊 PIPELINE CAPACITY PLANNING

### Quanto Pipeline Você Precisa?

**FÓRMULA**:
```
Pipeline Necessário = Meta de Revenue ÷ Taxa de Conversão Global

EXEMPLO:
Meta: R$ 500k/mês
Conversão: 5% (100 leads → 5 fechados)
Ticket Médio: R$ 100k

Cálculo:
R$ 500k ÷ 5% = R$ 10M em pipeline nominal

OU

5 deals/mês × R$ 100k = R$ 500k
Para 5 deals, preciso 100 leads (conversão 5%)

CONCLUSÃO: Preciso gerar 100 leads qualificados/mês
            = 25 leads/semana
            = 5 leads/dia útil
```

---

### Planejamento Reverso

**SE meta é R$ 2M/trimestre**:

```
TRABALHAR DE TRÁS PRA FRENTE:

Mês 3: Fechar R$ 700k
  ← Precisa R$ 1.4M em proposal (Mês 2)
    ← Precisa R$ 4.2M qualified (Mês 1)
      ← Precisa R$ 14M em leads (Mês 0)

AÇÃO HOJE (Mês 0):
Gerar R$ 14M em leads nominais
= 140 leads @ R$ 100k médio
= 35 leads/semana
```

---

## 🚀 IMPLEMENTAÇÃO

### SEMANA 1: Setup
- Definir stages do seu pipeline
- Estabelecer probabilidades por stage
- Criar planilha de tracking

### SEMANA 2: Baseline
- Medir métricas atuais
- Calcular conversões reais
- Identificar gargalos

### SEMANA 3: Optimize
- Implementar lead scoring
- Testar aceleradores
- Refinar forecast

### SEMANA 4: Scale
- Automatizar tracking
- Dashboard de métricas
- Rotinas semanais/mensais

**RESULTADO**: Pipeline saudável, previsível, escalável! 📊

---

**PIPELINE NÃO É ESTÁTICO.**  
**É ORGANISMO VIVO.**  
**CUIDE DELE. ELE CUIDA DE VOCÊ.** 🌱💰
