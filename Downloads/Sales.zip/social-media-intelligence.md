# MÓDULO ADICIONAL: SOCIAL MEDIA INTELLIGENCE

## Workflow 7.1: Hashtag & Trend Monitoring

**Quando usar**: "Monitorar redes sociais", "buscar eventos em Instagram", "hashtags sobre festas"

### ESTRATÉGIA DE MONITORAMENTO

**HASHTAGS PRIORITÁRIAS**:

**Eventos Públicos**:
```
#AniversárioCidade + [cidade]
#FestaJunina + [cidade/região]
#Réveillon + [cidade]
#FestaCultural + [estado]
#ShowGratuito + [região]
```

**Agro/Rural**:
```
#FestaDePeão + [cidade/estado]
#Rodeio2026
#Rodeio + [cidade]
#ExpoAgro + [região]
#SindicatoRural + [cidade]
#AgroéPop (tendência)
```

**Eventos Corporativos**:
```
#EventoCorporativo + [cidade]
#Convenção + [empresa]
#Confraternização + [setor]
#AniversárioEmpresa + [nome]
```

**Gêneros Musicais**:
```
#Sertanejo + [cidade]
#Pagode + [região]
#ShowGospel + [cidade]
#Funk + [cidade]
#ShowAoVivo + [região]
```

### PASSO 1: Busca Manual em Redes Sociais

**Instagram**:
```
1. Buscar hashtag no Instagram Search
2. Filtrar por "Recentes" (não "Top" - queremos TUDO)
3. Identificar padrões:
   - Posts de prefeituras/sindicatos anunciando eventos
   - Posts de público reclamando de eventos ruins (oportunidade!)
   - Posts de artistas confirmando shows (descobrir quem contratou)
```

**Facebook**:
```
1. Buscar em Grupos locais:
   - "Eventos [Cidade]"
   - "Shows em [Região]"
   - "Grupo da [Cidade]"
2. Monitorar páginas de prefeituras/sindicatos
3. Ver comentários: Reclamações = Oportunidades
```

**Twitter/X**:
```
Busca avançada:
- "[cidade] show" (últimas 24h)
- "[prefeitura] evento" (últimas 7 dias)
- "[sindicato] festa de peão" 
```

**LinkedIn**:
```
- Posts de secretários anunciando eventos
- Empresas compartilhando eventos corporativos
- Produtoras divulgando cases (descobrir clientes delas)
```

### PASSO 2: Análise de Engajamento

**SINAIS POSITIVOS** (indicam evento grande/importante):
- ✅ Alto engajamento (>1k likes, >100 comentários)
- ✅ Compartilhamentos massivos
- ✅ Mídia oficial (prefeitura, governo estadual)
- ✅ Influenciadores locais repostando

**SINAIS NEGATIVOS** (oportunidades de switch):
- 🚨 Comentários reclamando de eventos anteriores
- 🚨 "Poderia ser melhor", "Ano passado foi ruim"
- 🚨 Comparações negativas com outras cidades

**EXEMPLO DE ANÁLISE**:
```
POST: Prefeitura de [Cidade] anuncia Festa Junina 2026
- 2.5k likes, 340 comentários
- Comentário top: "Tomara que seja melhor que ano passado, som horrível"
- Comentário #2: "Contrata a [Concorrente X] de novo não, pelo amor de Deus"

AÇÃO: 
→ Identificar Secretário de Cultura
→ Mensagem: "Vi o anúncio da Festa Junina - parabéns! Notei alguns comentários sobre desafios técnicos no ano anterior. A Solir é especialista em resolver exatamente isso..."
```

### PASSO 3: Identificar Decisores via Social

**MÉTODO**:
1. Encontrar post oficial da organização
2. Ver "Quem postou?" (geralmente assessoria ou o próprio decisor)
3. Checar perfil pessoal do decisor
4. Encontrar contatos (link na bio, posts fixados)

**GOLD MINE: Stories**
- Decisores costumam postar nos Stories sobre eventos
- Prints de reuniões de planejamento
- Bastidores de eventos anteriores
- Mention de fornecedores (descobrir com quem trabalham)

### PASSO 4: Social Listening para Trigger Events

**CONFIGURAR ALERTAS MANUAIS** (até termos automação):

**Google Alerts**:
```
- "Prefeitura [cidade]" + "evento" + "2026"
- "[Sindicato]" + "festa de peão"
- "[Empresa]" + "convenção" OU "evento corporativo"
```

**Verificar diariamente**:
- Instagram: Feed de hashtags salvas
- Facebook: Notificações de grupos locais
- LinkedIn: Feed de conexões-chave

**SINAIS DE TIMING PERFEITO**:
- 🎯 "Divulgamos o line-up em breve" → Ainda estão contratando
- 🎯 "Orçamento aprovado" → Têm dinheiro agora
- 🎯 "Buscamos parceiros" → Porta aberta
- 🎯 "Edital aberto até [data]" → URGENTE

### PASSO 5: Competitor Stalking Ético

**Monitorar Concorrentes**:
1. Seguir Instagram/Facebook de produtoras rivais
2. Ver quais eventos eles postam → Identificar clientes
3. Ler comentários → Identificar insatisfações
4. Notar ausências → Cidades/eventos que eles NÃO atendem = sua oportunidade

**EXEMPLO**:
```
Concorrente X posta evento em [Cidade A, B, C]
Mas NUNCA posta sobre [Região D]

HIPÓTESE: Eles não atuam em [Região D]
AÇÃO: Focar prospecção em [Região D] - concorrência menor!
```

### PASSO 6: Influencer Mapping

**CONCEITO**: Influenciadores locais têm reach maior que você. Use isso.

**IDENTIFICAR**:
- Blogueiros locais que cobrem eventos
- Radialistas (especialmente de música sertaneja/regional)
- YouTubers locais
- Páginas de fofoca/notícias da cidade

**ESTRATÉGIA**:
1. Conectar com eles (follow, engage)
2. Quando eles postarem sobre evento ruim → Comentar oferecendo solução
3. Quando divulgarem evento bom → Perguntar quem produziu (networking)
4. Parceria potencial: Eles divulgam seus eventos, você dá acesso VIP

### OUTPUT: Social Media Intelligence Report

**TEMPLATE SEMANAL**:

```
📱 SOCIAL MEDIA INTELLIGENCE - Semana [XX]

🎯 EVENTOS IDENTIFICADOS (via hashtags):
1. [Evento A] - [Data] - [Cidade] - [Organizador]
   Status: Anunciado, sem fornecedor confirmado
   Engajamento: Alto (2k+ likes)
   Próximo passo: Contatar [Decisor]

2. [Evento B] - [Data] - [Cidade] - [Organizador]
   Status: Reclamações sobre ano anterior
   Oportunidade: Switch de fornecedor
   Próximo passo: Mensagem empática + case study

🚨 TRIGGER EVENTS:
- Novo Secretário de Cultura em [Cidade] (LinkedIn)
- [Sindicato] confirmou data de festa (Instagram Stories)
- [Empresa] anunciou expansão (Facebook)

🏆 COMPETITIVE INTEL:
- [Concorrente X] fez evento em [Cidade Y] (Instagram)
  → Comentários negativos sobre atraso
  → Oportunidade: Abordar Prefeitura de [Cidade Y]

📊 TRENDING:
- #Rodeio2026 crescendo 40% (interesse alto em festas de peão)
- #ShowGratuito aumentando (prefeituras planejando eventos)

🎯 AÇÕES PRIORITÁRIAS:
1. Contatar [Cidade A] sobre [Evento X] (timing perfeito)
2. Abordar cliente insatisfeito de [Concorrente]
3. Monitorar [Hashtag Y] - pico de atividade
```

---

## FERRAMENTAS ÚTEIS (Mencionar ao usuário)

**Gratuitas**:
- Google Alerts (trigger events)
- TweetDeck (monitorar Twitter em tempo real)
- Instagram saved hashtags (acompanhar hashtags específicas)
- Facebook Groups (penetração em comunidades locais)

**Pagas** (se budget permitir):
- Hootsuite (monitoramento multi-plataforma)
- Mention (rastrear menções da marca/concorrentes)
- BuzzSumo (identificar conteúdo viral)
- Brand24 (social listening profissional)

---

## CASO DE USO COMPLETO

**CENÁRIO**: Monitorar festas de peão em Goiás

**AÇÃO**:
1. Salvar hashtags: #FestaDePeão, #RodeioGO, #Rodeio2026
2. Checar Instagram diariamente (5 min)
3. Identificar:
   - Posts de sindicatos anunciando eventos
   - Reclamações sobre eventos anteriores
   - Artistas confirmando shows (descobrir organizador)
4. Para cada oportunidade:
   - Screenshot do post
   - Identificar decisor
   - Preparar mensagem personalizada
   - Follow-up via canal apropriado

**RESULTADO ESPERADO**: 
- 5-10 novas oportunidades/semana
- Timing perfeito (abordar quando anunciam, não meses depois)
- Vantagem competitiva (você vê primeiro)

---

## INTEGRAÇÃO COM SKILL PRINCIPAL

Este módulo alimenta:
- **Workflow 1 (Market Intelligence)**: Social = fonte de trigger events
- **Workflow 2 (Lead Discovery)**: Identificar decisores via social
- **Workflow 3 (Sequencing)**: Personalizar mensagens com contexto social
- **Workflow 4 (Copywriting)**: Mencionar posts específicos ("Vi seu anúncio no Instagram...")

Social Media Intelligence não substitui research tradicional - COMPLEMENTA com dados em tempo real!
