# 🔄 EXPANSÃO DE CONTAS & INBOUND STRATEGY

## 💎 FILOSOFIA: O CLIENTE MAIS FÁCIL

### Verdade Inconveniente

```
Custo de Adquirir Novo Cliente: R$ 5.000-10.000 (tempo + esforço)
Custo de Vender para Cliente Existente: R$ 500-1.000

Probabilidade de Fechar Novo Cliente: 5-10%
Probabilidade de Fechar Cliente Existente: 60-70%
```

**PRINCÍPIO**:
> **"Seu melhor prospect é quem já comprou de você."**

---

## 📈 EXPANSÃO VERTICAL (Upsell)

### Conceito: De Pequeno para Grande

**JORNADA DO CLIENTE**:
```
ANO 1: Evento pequeno (R$ 50k)
  ↓ (Se sucesso)
ANO 2: Evento médio (R$ 150k)
  ↓ (Se sucesso)
ANO 3: Evento grande (R$ 300k)
  ↓ (Se sucesso)
ANO 4: Festival multi-dia (R$ 800k)
```

---

### GATILHOS DE UPSELL

**GATILHO #1: Sucesso Mensurável**
```
Evento anterior:
• Público: 8k pessoas
• Satisfação: 92% (pesquisa)
• Mídia: 15 matérias positivas

APPROACH:
"[Nome], o evento foi um sucesso! Público de 8k, 
satisfação altíssima, mídia excelente.

Pensando no próximo: já considerou DOBRAR? 
Trazer 2 artistas ao invés de 1, fazer 2 dias ao 
invés de 1?

Com a base que vocês construíram, é totalmente viável."
```

---

**GATILHO #2: Crescimento Organizacional**
```
Cliente:
• ANO 1: Prefeitura 50k habitantes
• ANO 3: Prefeitura 70k habitantes (+40%)

APPROACH:
"[Nome], a cidade cresceu 40% em 3 anos. 
O evento precisa acompanhar!

Se em 2023 faziam evento de R$ 100k para 50k pessoas,
em 2026 faz sentido evento de R$ 150k para 70k.

Vamos dimensionar certo?"
```

---

**GATILHO #3: Comparação Regional**
```
DESCOBRIR:
Cidade vizinha fez evento maior/melhor

APPROACH:
"Vi que [Cidade Vizinha] fez festival de 3 dias 
ano passado. Vocês viram?

Acredito que [Sua Cidade] tem potencial para fazer 
MELHOR. Principalmente com o histórico de sucesso 
que vocês já têm.

Que tal explorarmos um formato maior para 2027?"
```

---

**GATILHO #4: Nova Gestão**
```
Novo prefeito/secretário assumiu

APPROACH:
"Parabéns pela nomeação, [Nome]!

Trabalhamos com a gestão anterior por X anos. 
Adoraríamos continuar e ajudar você a fazer sua 
primeira gestão ser memorável.

Inclusive, se quiser fazer algo DIFERENTE, inovador, 
que marque sua entrada, estamos à disposição para 
desenhar junto."
```

---

### FRAMEWORK: VALUE LADDER

**ESTRUTURA DE CRESCIMENTO**:

```
ENTRADA (R$ 20k-50k):
→ Evento único, artista regional, estrutura básica

CORE (R$ 50k-200k):
→ Evento anual, artista nacional médio, estrutura premium

PREMIUM (R$ 200k-500k):
→ Festival multi-dia, headliners, experiência completa

PLATINUM (>R$ 500k):
→ Produção integral anual, múltiplos eventos, parceria estratégica
```

**OBJETIVO**: Mover clientes pela escada ao longo do tempo.

---

## 🔀 EXPANSÃO HORIZONTAL (Cross-Sell)

### Conceito: Mais Eventos, Mesmo Cliente

**OPORTUNIDADES**:

**SE CLIENTE TIER 1: Prefeitura**
```
EVENTO ATUAL: Réveillon

CROSS-SELL:
• Aniversário da Cidade (maio/jun)
• Festas Juninas (junho)
• Dia da Independência (setembro)
• Natal (dezembro)

APPROACH:
"[Nome], o réveillon foi perfeito. Pensando no 
calendário: vocês têm interesse que a gente cuide 
dos outros eventos também?

Poderíamos fazer um pacote anual - 4 eventos com 
desconto. Vocês teriam parceiro fixo, a gente 
planeja tudo com antecedência."
```

---

**SE CLIENTE TIER 2: Sindicato Rural**
```
EVENTO ATUAL: Festa de Peão (agosto)

CROSS-SELL:
• Expo Agro (março)
• Dia do Produtor (maio)
• Confraternização de Fim de Ano (dezembro)

APPROACH:
"A festa de peão foi sucesso total. Mas vocês têm 
outros momentos importantes no ano, certo?

Que tal começarmos a criar tradições? Expo em março, 
Festa em agosto, Confraternização em dezembro.

Construir MARCA do sindicato, não só um evento."
```

---

**SE CLIENTE TIER 3: Igreja**
```
EVENTO ATUAL: Aniversário da Igreja

CROSS-SELL:
• Congresso de Jovens
• Retiro de Casais
• Cantata de Natal

APPROACH:
"Pastor, o aniversário abençoou muita gente. 
Conversamos sobre outros momentos ministeriais?

Jovens precisam de encontros. Casais de retiros. 
Natal de cantata especial.

Podemos fazer calendário ministerial completo, 
sempre com excelência."
```

---

### FRAMEWORK: ANNUAL PARTNERSHIP

**CONTRATO ANUAL vs. EVENTO ÚNICO**:

```
MODELO ANTIGO (Evento Único):
• Cliente: Negocia preço TODO ANO
• Você: Incerteza (vai renovar?)
• Margem: Comprimida (competição)

MODELO NOVO (Parceria Anual):
• Cliente: Desconto (R$ 800k ao invés de R$ 900k)
• Você: Previsibilidade (revenue garantido)
• Margem: Protegida (relacionamento)

BENEFÍCIOS:
✅ Cliente: Economia 10-15%
✅ Você: Revenue recorrente
✅ Ambos: Relacionamento profundo
```

---

### PROPOSTA DE PARCERIA ANUAL

**TEMPLATE**:
```
PROPOSTA: PARCERIA ANUAL 2026
Cliente: Prefeitura de [Cidade]

ESCOPO:
1. Réveillon 2025/2026: R$ 400k
2. Aniversário (Maio): R$ 250k
3. São João (Junho): R$ 200k
4. Independência (Set): R$ 150k

TOTAL EVENTOS INDIVIDUAIS: R$ 1.000.000
PACOTE ANUAL: R$ 850.000 (15% desconto)

ECONOMIA: R$ 150.000

BENEFÍCIOS ADICIONAIS:
✅ Planejamento integrado (todos eventos alinhados)
✅ Prioridade em datas (artistas bloqueados primeiro)
✅ Desconto progressivo (quanto mais, maior desconto)
✅ Gestão de cronograma anual
✅ Relatórios mensais de execução

CONDIÇÕES:
• Pagamento: 30-40-30
• Vigência: Jan-Dez 2026
• Renovação automática (salvo aviso 60 dias)

Investimento Total: R$ 850.000
Parcelado: 10× R$ 85.000
```

---

## 🎁 ESTRATÉGIA DE RETENÇÃO

### Fase 1: Post-Event Care

**IMEDIATAMENTE APÓS EVENTO** (24-48h):
```
Email/WhatsApp:
"[Nome], evento finalizado com sucesso! 🎉

Obrigado pela confiança. Tudo correu conforme 
planejado:
✅ Artista pontual
✅ Público estimado em [X] pessoas
✅ Zero intercorrências

Nos próximos dias vou te enviar:
• Fotos profissionais do evento
• Relatório de execução
• Clipping de mídia

Qualquer feedback, estou à disposição!"
```

---

**1 SEMANA APÓS** (Follow-up):
```
Email com:
• 📸 Álbum de fotos (Google Drive)
• 📊 Relatório executivo (1 página)
• 📰 Clipping de mídia (matérias/posts)
• ⭐ Pedido de depoimento

"[Nome], segue material do evento. 

Se possível, adoraria um breve depoimento seu 
sobre a experiência. Ajuda muito no nosso 
trabalho.

Abraço!"
```

---

### Fase 2: Nurturing (Manter Vivo)

**ESTRATÉGIA: Touch Without Selling**

**MENSAL**:
```
• Enviar conteúdo relevante:
  - "10 Tendências de Eventos para 2026"
  - "Case Study: Como [Cidade X] dobrou público"
  - "Artistas em alta para segundo semestre"
  
NÃO vender. Apenas agregar valor.
```

**TRIMESTRAL**:
```
• Check-in casual:
  "Oi [Nome], tudo bem? Vi que [evento recente 
  na cidade]. Ficou legal!
  
  Só lembrando que estamos por aqui para 
  qualquer coisa. Abraço!"
```

**ANUAL** (Aniversário do Evento):
```
• Email nostálgico:
  "Há 1 ano fizemos [Evento X] juntos. Que saudade!
  
  [Foto do evento]
  
  Pronto para 2026? 😊"
```

---

### Fase 3: Expansion Triggers

**MONITORAR**:
- Orçamento aprovado (Portal Transparência)
- Novo gestor nomeado (Diário Oficial)
- Cidade vizinha fez evento (competição)
- Crescimento populacional (IBGE)

**QUANDO TRIGGER ACONTECER**:
```
"[Nome], vi que [trigger]. Parabéns!

Isso abre possibilidade de [oportunidade].

Topa conversar 15 min sobre como podemos 
ajudar?"
```

---

## 🧲 INBOUND STRATEGY (Prospects Vêm Até Você)

### Conceito: Magnetic Positioning

**SHIFT MENTAL**:
```
ANTES: Caçar clientes (outbound)
DEPOIS: Atrair clientes (inbound)

Ambos são necessários. Mas inbound é escalável.
```

---

### PILAR 1: Content Marketing

**CRIAR AUTORIDADE via CONTEÚDO**:

**LinkedIn (B2B)**:
```
POST SEMANAL:
• Segunda: Dica prática
  "3 erros que prefeituras cometem ao contratar 
  shows (e como evitar)"
  
• Quarta: Case study
  "Como a Prefeitura de [X] dobrou o público 
  gastando 30% menos"
  
• Sexta: Tendência/Insight
  "Por que festivais de 2 dias estão substituindo 
  eventos de 1 noite"
```

**Instagram (Showcase)**:
```
• Feed: Fotos de eventos (portfolio visual)
• Stories: Bastidores, dia a dia
• Reels: Momentos épicos de shows
• Highlights: "Réveillon", "Festas", "Gospel", etc.

OBJETIVO: Quando prospect pesquisar, 
          ver que você É REFERÊNCIA.
```

**Blog/Site** (SEO):
```
ARTIGOS EVERGREEN:
• "Quanto custa contratar [Artista X] em 2026"
• "Guia completo: Organizar festa de peão"
• "Checklist: Contratar show para prefeitura"
• "ROI de eventos públicos: Como medir"

OBJETIVO: Ranquear no Google para buscas relevantes.
```

---

### PILAR 2: Social Proof Sistemático

**COLETAR DEPOIMENTOS**:

```
EMAIL (1 semana pós-evento):
"[Nome], adoraria um breve depoimento!

Pode responder 3 perguntas?
1. Qual foi o principal desafio antes de trabalhar conosco?
2. Como foi a experiência de trabalhar conosco?
3. Qual resultado mais te surpreendeu?

Vou usar no site (com sua autorização, claro!)"
```

**FORMATO**:
```
Video Testimonial (ideal):
• 30-60 segundos
• Cliente em ambiente profissional
• Fala espontânea (não decorada)

Texto (alternativa):
• 2-3 parágrafos
• Quote destacável
• Foto do cliente + logo da organização
```

---

### PILAR 3: Referral Program

**TRANSFORMAR CLIENTES EM VENDEDORES**:

**ESTRUTURA**:
```
PROGRAMA: Indique e Ganhe

MECÂNICA:
• Cliente indica novo cliente
• Novo cliente fecha (mín. R$ 50k)
• Cliente recebe:
  → Desconto 10% no próximo evento
  OU
  → Upgrade gratuito (artista abertura)
  OU
  → R$ 5.000 em crédito

LEGAL:
• Novo cliente não pode saber do desconto
  (evita negociação baseada nisso)
• Válido por 12 meses
```

**APPROACH**:
```
EMAIL (pós-evento bem-sucedido):
"[Nome], evento foi sensacional!

Tenho um pedido: conhece outras prefeituras/
sindicatos que poderiam se beneficiar do mesmo?

Se indicar e eles fecharem, você ganha [benefício].

Pensou em alguém?"
```

---

### PILAR 4: Eventos Próprios

**CRIAR OPORTUNIDADES DE NETWORKING**:

**FORMATO 1: Workshop Gratuito**
```
TÍTULO: "Como Organizar Eventos Públicos de Sucesso"

TARGET: Secretários de Cultura, Coordenadores

CONTEÚDO:
• Planejamento (6 meses antes)
• Seleção de artistas (fit com público)
• Gestão de orçamento (onde economizar)
• Evitar erros comuns
• Q&A

DURAÇÃO: 2h (presencial ou online)

RESULTADO: 30-50 participantes
           = 30-50 prospects qualificados!
```

**FORMATO 2: Networking Event**
```
TÍTULO: "Encontro de Produtores Culturais de Goiás"

CONVIDAR:
• Secretários de Cultura
• Presidentes de Sindicatos
• Diretores de Clubes
• Agentes de Artistas

FORMATO:
• Happy hour casual
• Apresentação rápida (10 min)
• Networking livre

RESULTADO: Relacionamentos, referências, deals
```

---

### PILAR 5: Partnerships Estratégicas

**PARCERIAS QUE TRAZEM LEADS**:

**PARCEIRO 1: Agências de Publicidade**
```
PROPOSTA:
"Vocês cuidam da comunicação/marketing.
Nós cuidamos da produção do evento.

Cliente tem solução completa, 
nós dividimos revenue."

SPLIT: 80/20 ou 70/30 (negociar)
```

**PARCEIRO 2: Fornecedores Técnicos**
```
PROPOSTA:
"Quando cliente pedir só estrutura, 
vocês fazem.

Se pedir artista também, 
vocês indicam a gente."

COMISSÃO: 10-15% do valor do artista
```

**PARCEIRO 3: Associações/Federações**
```
EXEMPLO: FAEG (Federação Agricultura GO)

PROPOSTA:
"Podemos fazer workshop sobre 'Festas de Sucesso' 
para todos os sindicatos filiados?

Sem custo, puro valor. Depois, os que quiserem 
contratar, contratam."

RESULTADO: Acesso a 100+ sindicatos de uma vez
```

---

## 📊 MÉTRICAS DE EXPANSÃO & INBOUND

### KPIs de Retenção

```
• Taxa de Renovação: ___% (meta: >70%)
• Lifetime Value Médio: R$ ___ (aumentando?)
• Tempo Médio de Retenção: ___ anos
• Net Promoter Score: ___ (0-10, meta: >8)
```

### KPIs de Expansão

```
• % Clientes que Upsell: ___% (meta: 30%)
• % Clientes que Cross-Sell: ___% (meta: 20%)
• Revenue de Expansão vs. Novo: ___% (meta: 40/60)
• Ticket Médio Ano 1 vs. Ano 3: R$ ___ → R$ ___
```

### KPIs de Inbound

```
• Leads Inbound/mês: ___
• Custo por Lead Inbound: R$ ___ (vs. outbound)
• Taxa Conversão Inbound: ___% (geralmente >outbound)
• Origem: LinkedIn _%, Google _%, Referral ___%, Evento ____%
```

---

## 🚀 IMPLEMENTAÇÃO

### MÊS 1: Retenção
- Criar processo post-event
- Template de nurturing
- Coletar 5 depoimentos

### MÊS 2: Expansão
- Mapear clientes para upsell
- Desenhar proposta parceria anual
- Abordar top 5 clientes

### MÊS 3: Inbound - Content
- Criar calendário editorial
- Publicar 4 posts LinkedIn
- 1 artigo no blog

### MÊS 4: Inbound - Referral
- Lançar programa
- Comunicar a todos clientes
- Primeiras indicações

### MÊS 5: Inbound - Eventos
- Organizar primeiro workshop
- Convidar 50 prospects
- Follow-up pós-evento

### MÊS 6: Inbound - Partnerships
- Identificar 3 parceiros potenciais
- Propor colaboração
- Fechar 1-2 parcerias

**RESULTADO**: Sistema completo de crescimento orgânico! 🌱

---

## 💡 CASOS DE SUCESSO

### CASO 1: Prefeitura que Virou Parceira Anual

```
ANO 1: 
• Evento: Réveillon
• Valor: R$ 300k
• Resultado: Sucesso

ANO 2:
• Upsell: Réveillon maior (R$ 400k)
• Cross-sell: Aniversário (R$ 200k)
• Total: R$ 600k (+100%)

ANO 3:
• Parceria Anual: 4 eventos
• Valor: R$ 850k (+42%)
• Margem: 28% (vs. 22% ano 1)

LIFETIME VALUE: R$ 1.75M
```

---

### CASO 2: Sindicato que Indicou 3 Outros

```
CLIENTE ORIGINAL: Sindicato A
• Festa de Peão: R$ 400k
• Satisfação: 10/10

INDICAÇÕES:
• Sindicato B (vizinho): R$ 350k
• Sindicato C (mesmo estado): R$ 300k
• Sindicato D (federação): R$ 450k

TOTAL GERADO POR INDICAÇÃO: R$ 1.1M
CUSTO AQUISIÇÃO: R$ 0 (referral)
```

---

### CASO 3: Workshop que Gerou 12 Leads

```
EVENTO: "Workshop Eventos Públicos de Sucesso"
• Participantes: 45
• Leads qualificados: 12
• Conversão: 3 deals
• Valor Total: R$ 720k

CUSTO:
• Local: R$ 0 (parceria)
• Café: R$ 500
• Material: R$ 200

ROI: 1.000x 🚀
```

---

**NÃO BUSQUE APENAS CLIENTES.**  
**CONSTRUA RELACIONAMENTOS.**  
**RELACIONAMENTOS ESCALAM.** 💎🔄
