# 🛠️ FERRAMENTAS & AUTOMAÇÕES - ACCOUNT RESEARCH

## 🎯 STACK TECNOLÓGICO RECOMENDADO

### TIER 1: GRATUITO (Começar Aqui)

```
┌────────────────────────────────────────────┐
│ FERRAMENTAS ESSENCIAIS (Custo: R$ 0)      │
├────────────────────────────────────────────┤
│                                            │
│ 📊 CRM & TRACKING                          │
│ • Google Sheets (planilhas)               │
│ • Google Calendar (timing map)            │
│ • Google Keep (notas rápidas)             │
│                                            │
│ 🔍 RESEARCH                                │
│ • Google Search (óbvio mas subestimado)   │
│ • Portal da Transparência (gov data)      │
│ • Instagram/Facebook (social intel)       │
│ • LinkedIn (decisor profiling)            │
│ • Google Alerts (trigger events)          │
│                                            │
│ 📧 COMUNICAÇÃO                             │
│ • Gmail (email)                            │
│ • WhatsApp Web (messaging)                │
│ • LinkedIn Messages (networking)          │
│                                            │
│ 📝 PRODUTIVIDADE                           │
│ • Google Docs (proposals)                  │
│ • Loom (vídeos de apresentação)           │
│ • Canva Free (materiais visuais)          │
│                                            │
└────────────────────────────────────────────┘
```

**ROI**: Setup de 3 horas = Sistema funcional grátis para sempre

---

### TIER 2: FREEMIUM (R$ 0-100/mês)

```
┌────────────────────────────────────────────┐
│ UPGRADE PRODUTIVIDADE                      │
├────────────────────────────────────────────┤
│                                            │
│ 🤖 AUTOMAÇÃO BÁSICA                        │
│ • Zapier Free (100 tasks/mês)             │
│   → Email respondido = Update CRM         │
│   → Novo lead = Notificação WhatsApp      │
│                                            │
│ 📧 EMAIL TRACKING                          │
│ • Mailtrack (Gmail tracker - grátis)      │
│   → Saber quando abriram email            │
│                                            │
│ 📊 CRM REAL                                │
│ • HubSpot CRM (100% grátis!)              │
│   → Pipeline visual                        │
│   → Email sequences                        │
│   → Tracking automático                    │
│                                            │
│ 🗓️ SCHEDULING                              │
│ • Calendly Básico (R$ 0)                  │
│   → Link de agendamento automático        │
│                                            │
└────────────────────────────────────────────┘
```

**ROI**: R$ 0-50/mês = 2-3x produtividade

---

### TIER 3: PROFISSIONAL (R$ 200-500/mês)

```
┌────────────────────────────────────────────┐
│ FERRAMENTAS PRO                            │
├────────────────────────────────────────────┤
│                                            │
│ 💼 CRM AVANÇADO                            │
│ • Pipedrive (R$ 150/mês)                  │
│   → Pipeline management                    │
│   → Relatórios avançados                   │
│   → Integrações                            │
│                                            │
│ 🔍 LEAD ENRICHMENT                         │
│ • Apollo.io Básico (R$ 200/mês)           │
│   → Dados de contato automáticos          │
│   → Company info                           │
│                                            │
│ 📧 COLD EMAIL                              │
│ • Lemlist (R$ 150/mês)                    │
│   → Sequências personalizadas             │
│   → Tracking avançado                      │
│   → A/B testing                            │
│                                            │
│ 🎨 DESIGN                                  │
│ • Canva Pro (R$ 50/mês)                   │
│   → Templates premium                      │
│   → Brand kit                              │
│                                            │
└────────────────────────────────────────────┘
```

**ROI**: R$ 500/mês = 5-10x produtividade

**RECOMENDAÇÃO**: Começar Tier 1 → Migrar Tier 2 após 3 meses → Tier 3 quando revenue justificar

---

## 🤖 AUTOMAÇÕES PRÁTICAS (ZAPIER)

### Automação 1: "Prospect Respondeu Email"

**TRIGGER**: Email recebido com tag "Prospect"

**AÇÕES**:
1. Atualizar status no Google Sheets: "Contacted" → "Engaged"
2. Criar tarefa no Google Tasks: "Responder [Nome] hoje"
3. Enviar notificação WhatsApp (via Zapier SMS)
4. Add +10 pontos no Lead Score

**SETUP**:
```
Zapier.com → Create Zap

1. TRIGGER: Gmail - New Email Matching Search
   Search String: label:prospect

2. ACTION 1: Google Sheets - Update Row
   Spreadsheet: CRM Master
   Column: Status
   Value: "Engaged"

3. ACTION 2: Google Tasks - Create Task
   Title: "Responder {{Nome}}"
   Due: Today

4. ACTION 3: SMS by Zapier - Send SMS
   To: [Seu WhatsApp]
   Message: "🔥 Lead {{Nome}} respondeu!"
```

**ECONOMIA**: 10-15 min/dia de check manual

---

### Automação 2: "Novo Edital Publicado"

**TRIGGER**: Google Alert de "licitação evento Goiás"

**AÇÕES**:
1. Parsear email (extrair cidade, valor, objeto)
2. Adicionar linha em "Planilha de Editais"
3. Se valor > R$ 200k: Notificação URGENTE

**SETUP**:
```
1. TRIGGER: Gmail - New Email
   From: googlealerts-noreply@google.com
   Subject: licitação evento

2. ACTION 1: Google Sheets - Create Row
   Spreadsheet: Editais Tracking
   Columns: Data, Cidade, Valor, Link

3. ACTION 2: Filter (only continue if)
   Condition: Valor > 200000

4. ACTION 3: Send WhatsApp
   Message: "📄 EDITAL HOT! {{Cidade}} - R$ {{Valor}}"
```

---

### Automação 3: "Follow-up Esquecido"

**TRIGGER**: Todos os dias 8h

**LÓGICA**: Checar CRM → Leads sem atividade >3 dias → Criar tarefa

**SETUP (Google Apps Script)**:

```javascript
function checkStaleLeads() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName('Master List');
  const data = sheet.getDataRange().getValues();
  
  const hoje = new Date();
  
  for (let i = 1; i < data.length; i++) {
    const ultimaInteracao = new Date(data[i][10]); // Coluna última interação
    const diasSemContato = Math.floor((hoje - ultimaInteracao) / (1000*60*60*24));
    
    if (diasSemContato >= 3 && data[i][6] === 'Contacted') {
      // Criar tarefa
      Tasks.Tasks.insert({
        title: `Follow-up ${data[i][1]}`, // Nome do prospect
        notes: 'Lead sem contato há 3+ dias'
      }, '@default');
    }
  }
}

// Configurar trigger para rodar diariamente às 8h
```

---

## 📊 PORTAL DA TRANSPARÊNCIA - SCRIPTS ÚTEIS

### Script 1: Extrator de Orçamentos (Python)

**USE CASE**: Extrair orçamento de cultura de múltiplas prefeituras automaticamente

```python
import requests
from bs4 import BeautifulSoup
import pandas as pd

def extrair_orcamento_cultura(cidade):
    """
    Extrai orçamento de cultura de portal de transparência
    
    NOTA: Cada portal tem estrutura diferente - este é um template
    que precisa ser customizado por prefeitura
    """
    
    url = f"https://transparencia.{cidade}.go.gov.br/despesas"
    
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Buscar função "Cultura" (código 13)
        # Estrutura varia por portal - adaptar conforme necessário
        cultura_row = soup.find('td', text='13 - Cultura')
        
        if cultura_row:
            valor = cultura_row.find_next_sibling('td', class_='valor')
            orcamento = valor.text.strip()
            
            return {
                'cidade': cidade,
                'orcamento_cultura': orcamento,
                'fonte': url,
                'data_extracao': pd.Timestamp.now()
            }
    except Exception as e:
        print(f"Erro em {cidade}: {e}")
        return None

# Usar
cidades = ['caldasnovas', 'anapolis', 'rioverde', 'catalao']
resultados = [extrair_orcamento_cultura(c) for c in cidades]

# Salvar em planilha
df = pd.DataFrame([r for r in resultados if r])
df.to_csv('orcamentos_cultura_goias.csv', index=False)

print(f"✅ Extraídos orçamentos de {len(df)} prefeituras")
```

**IMPORTANTE**: Cada portal tem estrutura própria. Este script precisa ser customizado por cidade.

---

### Script 2: Monitor de Diário Oficial (Python)

**USE CASE**: Alertar quando novo secretário for nomeado

```python
import requests
import re
from datetime import datetime

def monitorar_nomeacoes_secretario():
    """
    Monitora Diário Oficial de Goiás para nomeações de Secretários de Cultura
    """
    
    url_do = "https://diariooficial.go.gov.br/api/publicacoes/hoje"
    
    response = requests.get(url_do)
    publicacoes = response.json()
    
    secretarios_nomeados = []
    
    for pub in publicacoes:
        texto = pub['texto'].lower()
        
        # Regex para detectar nomeação de secretário de cultura
        if 'nomear' in texto and 'secretári' in texto and 'cultura' in texto:
            # Extrair nome (padrão típico: "nomear NOME COMPLETO")
            match = re.search(r'nomear\s+([A-ZÁÀÂÃÉÈÊÍÏÓÔÕÖÚÇÑ\s]+)', 
                            pub['texto'], re.IGNORECASE)
            
            if match:
                nome = match.group(1).strip()
                cidade = pub.get('municipio', 'Estadual')
                
                secretarios_nomeados.append({
                    'nome': nome,
                    'cidade': cidade,
                    'data': datetime.now(),
                    'decreto': pub['numero']
                })
                
                print(f"🔔 ALERTA: {nome} nomeado em {cidade}")
    
    return secretarios_nomeados

# Rodar diariamente via cron job
if __name__ == "__main__":
    nomeacoes = monitorar_nomeacoes_secretario()
    
    if nomeacoes:
        # Enviar notificação (email, WhatsApp, etc.)
        print(f"Encontradas {len(nomeacoes)} nomeações hoje!")
```

---

## 🔍 SCRAPING DE REDES SOCIAIS (Ético)

### Script 3: Instagram Hashtag Monitor (Python)

**USE CASE**: Monitorar #FestaDePeão para novos eventos

**NOTA**: Instagram API é restrita. Este script usa método manual.

```python
from instaloader import Instaloader, Hashtag
import pandas as pd

def monitorar_hashtag(hashtag_name, limite=50):
    """
    Baixa posts recentes de uma hashtag
    
    NOTA: Requer login no Instagram (use conta descartável)
    """
    
    L = Instaloader()
    
    # Login (necessário para acessar hashtags)
    # L.login('usuario', 'senha')  # Use conta descartável!
    
    posts_data = []
    
    try:
        hashtag = Hashtag.from_name(L.context, hashtag_name)
        
        for post in hashtag.get_posts():
            if len(posts_data) >= limite:
                break
                
            posts_data.append({
                'data': post.date,
                'usuario': post.owner_username,
                'caption': post.caption,
                'likes': post.likes,
                'url': f"https://instagram.com/p/{post.shortcode}",
                'location': post.location.name if post.location else None
            })
        
        df = pd.DataFrame(posts_data)
        df.to_csv(f'instagram_{hashtag_name}.csv', index=False)
        
        print(f"✅ {len(posts_data)} posts de #{hashtag_name}")
        return df
        
    except Exception as e:
        print(f"Erro: {e}")
        return None

# Usar
hashtags = ['FestaDePeao', 'RodeioGO', 'EventoGoias']
for tag in hashtags:
    monitorar_hashtag(tag)
```

**AVISO LEGAL**: 
- Use apenas para research público
- Respeite ToS do Instagram
- Não faça scraping agressivo (rate limits)
- Considere usar API oficial quando possível

---

## 📱 GOOGLE ALERTS - CONFIGURAÇÃO OTIMIZADA

### Setup Estratégico

**ALERTAS ESSENCIAIS** (Configurar todos):

**CATEGORIA 1: Licitações**
```
1. "licitação" + "evento" + "Goiás"
2. "edital" + "show" + "Goiás"
3. "pregão" + "artista" + "Goiás"
4. "inexigibilidade" + "show"
5. each: "licitação evento [CidadeChave]" (top 10 cidades)
```

**CATEGORIA 2: Orçamentos**
```
6. "orçamento aprovado" + "cultura" + "Goiás"
7. "LOA" + "cultura" + "Goiás"
8. "repasse" + "cultura" + "município"
```

**CATEGORIA 3: Eventos**
```
9. "festa de peão" + "2026" + "Goiás"
10. "rodeio" + "2026" + "Goiás"
11. "aniversário cidade" + "Goiás"
12. "réveillon" + "Goiás"
```

**CATEGORIA 4: Trigger Events**
```
13. "secretário cultura" + "nomeado" + "Goiás"
14. "prefeito eleito" + "Goiás"
15. "orçamento extra" + "evento"
```

**CATEGORIA 5: Competitiva**
```
16. "[ConcorrenteA]" + "evento"
17. "[ConcorrenteB]" + "show"
(monitorar onde concorrentes atuam)
```

**CONFIGURAÇÃO**:
- Frequência: "No máximo uma vez por dia" (evitar spam)
- Fontes: "Notícias" (mais confiável que "Tudo")
- Idioma: Português
- Região: Brasil
- Entregar para: Email específico (ex: alertas@empresa.com)

---

## 🗂️ SISTEMA DE ARQUIVOS & ORGANIZAÇÃO

### Estrutura Dropbox/Google Drive

```
📁 Solir Produções
├─ 📁 PROSPECTS
│  ├─ 📁 Tier 1 - Grande (>200k)
│  │  ├─ 📄 Caldas Novas - Discovery Matrix.pdf
│  │  ├─ 📄 Anápolis - Discovery Matrix.pdf
│  │  └─ ...
│  ├─ 📁 Tier 2 - Médio (50-200k)
│  ├─ 📁 Tier 3 - Pequeno (15-50k)
│  └─ 📁 Tier 4 - Micro (<15k)
│
├─ 📁 RESEARCH
│  ├─ 📄 Orçamentos Cultura - Goiás 2026.xlsx
│  ├─ 📄 Editais Ativos.xlsx
│  ├─ 📄 Secretários Cultura - Contatos.xlsx
│  └─ 📄 Eventos Anuais - Calendario.xlsx
│
├─ 📁 TEMPLATES
│  ├─ 📄 Discovery Matrix - Template.docx
│  ├─ 📄 Email Prefeitura - Template.txt
│  ├─ 📄 Email Sindicato - Template.txt
│  └─ 📄 Proposta Comercial - Template.docx
│
├─ 📁 PROPOSTAS
│  ├─ 📁 2026-Q1
│  ├─ 📁 2026-Q2
│  └─ ...
│
└─ 📁 CASES & PORTFOLIO
   ├─ 📁 Fotos Eventos
   ├─ 📁 Depoimentos
   └─ 📄 Portfolio Solir 2026.pdf
```

---

## ⏱️ ROTINAS & CHECKLIST SEMANAL

### SEGUNDA-FEIRA (1h)

```
☐ 8h00-8h30: Review Google Alerts
   • Novos editais? Adicionar planilha
   • Trigger events? Atualizar prospects

☐ 8h30-9h00: Social Media Check
   • Instagram: 5 hashtags principais
   • Facebook: 3 grupos locais
   • LinkedIn: Feed de conexões-chave
```

### TERÇA-FEIRA (2h)

```
☐ 9h00-10h00: Batch Research
   • Escolher 5 prospects novos
   • Fazer research básico (15 min cada)
   • Adicionar ao CRM

☐ 10h00-11h00: Portal da Transparência
   • Checar 3 prefeituras tier 1
   • Atualizar orçamentos na planilha
```

### QUARTA-FEIRA (2h)

```
☐ 14h00-15h00: Diário Oficial
   • Checar DO de Goiás
   • Buscar: licitações, nomeações
   • Atualizar planilha de editais

☐ 15h00-16h00: Outreach
   • Email para top 3 hot leads
   • LinkedIn para warm leads
   • Follow-up ligações pendentes
```

### QUINTA-FEIRA (1h)

```
☐ 14h00-15h00: CRM Hygiene
   • Atualizar interações da semana
   • Mover leads entre stages
   • Identificar follow-ups atrasados
```

### SEXTA-FEIRA (1h)

```
☐ 17h00-17h30: Weekly Review
   • Leads novos: ___
   • Interações: ___
   • Reuniões agendadas: ___
   • Propostas enviadas: ___

☐ 17h30-18h00: Planejar Próxima Semana
   • Priorizar top 5 actions
   • Agendar blocos de research
   • Definir metas
```

**TOTAL**: 7h/semana em research e prospecção

---

## 📈 MÉTRICAS DE RESEARCH (Tracking)

### Planilha de Métricas Semanais

| Semana | Prospects Novos | Research Completo | Hot Leads | Outreaches | Respostas | Reuniões | Propostas |
|--------|----------------|-------------------|-----------|------------|-----------|----------|-----------|
| 01 | 8 | 5 | 2 | 5 | 1 | 0 | 0 |
| 02 | 10 | 7 | 3 | 8 | 2 | 1 | 0 |
| 03 | 12 | 10 | 5 | 12 | 4 | 2 | 1 |

**KPIs**:
- Taxa de Conversão Research → Outreach: 70%+
- Taxa de Resposta Outreach: 15-25%
- Taxa Reunião Agendada: 30-40%
- Taxa Proposta Enviada: 60-70%

---

## 🎯 TROUBLESHOOTING

### Problema 1: "Portal da Transparência não carrega"

**SOLUÇÕES**:
- Tentar em navegador anônimo
- Desabilitar AdBlock
- Tentar horário diferente (portais caem à noite)
- Ligar na prefeitura e pedir dados por LAI

---

### Problema 2: "Não encontro decisor em lugar nenhum"

**SOLUÇÕES**:
- Ligar na central da prefeitura: "Preciso falar com responsável por eventos"
- LinkedIn: Buscar "[Cidade] governo" filtrar por pessoas
- Facebook: Buscar página oficial, ver quem posta
- Imprensa local: Geralmente cita nomes

---

### Problema 3: "Muitos prospects, pouco tempo"

**SOLUÇÕES**:
- Focar apenas Tier 1 e 2
- Usar batch research (lote de 10)
- Terceirizar research básico (estagiário)
- Automação de dados públicos

---

### Problema 4: "Dados do Portal desatualizados"

**SOLUÇÕES**:
- Cruzar com notícias recentes
- Ligar e perguntar discretamente
- Usar histórico como baseline, ajustar +/- 10%

---

## 💡 HACKS & SHORTCUTS

### Hack 1: Atalhos de Busca Google

```
site:prefeitura*.go.gov.br "secretaria de cultura"
→ Encontra todas secretarias de GO

site:transparencia*.gov.br "função cultura"
→ Encontra portais com dados de cultura

filetype:pdf "edital" "evento" "Goiás"
→ Encontra PDFs de editais
```

### Hack 2: Reverse Image Search

Viu foto de evento mas não sabe qual?
→ Google Images → Upload da foto → Descobrir origem

### Hack 3: LinkedIn Sales Navigator (Free Trial)

- 1 mês grátis
- Busca avançada: "Secretário" + "Cultura" + "Goiás"
- Export leads
- Cancelar antes de cobrar

---

## 🚀 IMPLEMENTAÇÃO: SEMANA 1

**DIA 1**:
- [ ] Configurar 15 Google Alerts
- [ ] Criar planilha CRM básica
- [ ] Salvar 5 hashtags Instagram

**DIA 2**:
- [ ] Batch research: 5 prefeituras tier 1
- [ ] Preencher Discovery Matrix

**DIA 3**:
- [ ] Portal Transparência: 3 prefeituras
- [ ] Extrair orçamentos

**DIA 4**:
- [ ] Encontrar decisores (nome + contato)
- [ ] Adicionar ao CRM

**DIA 5**:
- [ ] Review da semana
- [ ] Planejar outreach semana 2

**RESULTADO**: Sistema funcionando, 5 prospects bem-pesquisados!

---

**FERRAMENTAS SÃO MULTIPLICADORES.  
USE-AS SABIAMENTE.** 🛠️🚀
