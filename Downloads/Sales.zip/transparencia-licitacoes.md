# MÓDULO ADICIONAL: PORTAL DA TRANSPARÊNCIA & LICITAÇÕES

## Workflow 7.2: Budget Intelligence (Orçamento Público)

**Quando usar**: "Quanto a prefeitura tem de orçamento?", "Descobrir budget público", "Análise de orçamento cultura"

### CONCEITO: FOLLOW THE MONEY

Ao invés de PERGUNTAR quanto eles têm de orçamento, DESCUBRA nos dados públicos!

### PASSO 1: Acessar Portal da Transparência

**FONTES OFICIAIS**:

**Federal**:
- Portal da Transparência Federal: portaldatransparencia.gov.br
- Convênios e repasses para municípios

**Estadual** (Goiás):
- Portal da Transparência GO: transparencia.go.gov.br
- Repasses para prefeituras

**Municipal**:
- Cada prefeitura tem seu portal (geralmente: transparencia.prefeitura[cidade].go.gov.br)
- Lei de Acesso à Informação (LAI) obriga publicação

### PASSO 2: Navegar até Orçamento de Cultura

**CAMINHO TÍPICO**:
```
Portal da Transparência
→ Receitas e Despesas
→ Despesas por Função/Subfunção
→ Função: CULTURA (13)
→ Ver detalhamento por programa/ação
```

**O QUE BUSCAR**:

**1. Orçamento Aprovado (LOA - Lei Orçamentária Anual)**:
- Quanto foi PREVISTO para cultura no ano
- Geralmente publicado em dez/jan do ano anterior

**2. Execução Orçamentária**:
- Quanto foi GASTO até agora
- Quanto ainda tem DISPONÍVEL

**3. Empenhos**:
- Contratos já firmados (dinheiro comprometido)
- Com quem contrataram (fornecedores anteriores)

**4. Licitações e Contratos**:
- Editais abertos (oportunidades ATIVAS)
- Contratos vigentes (descobrir concorrentes)

### PASSO 3: Análise de Dados

**EXEMPLO PRÁTICO - Prefeitura de Caldas Novas**:

```
[Acessar portal da transparência]
→ Despesas > Função Cultura

DESCOBERTAS:
- Orçamento 2026: R$ 2.500.000
- Executado até março: R$ 400.000
- Disponível: R$ 2.100.000

DETALHAMENTO:
- Festividades e eventos: R$ 1.200.000
  - Réveillon: R$ 450.000 (empenho já existe?)
  - Aniversário da cidade: R$ 300.000
  - Festas Juninas: R$ 200.000
  - Outros eventos: R$ 250.000

- Contratações recentes:
  - Empresa X (som e luz): R$ 80k
  - Empresa Y (artista Z): R$ 150k
  - Produtora W: R$ 200k (pacote completo)
```

**INSIGHTS ACIONÁVEIS**:
✅ Eles TÊM budget de R$ 450k para réveillon
✅ Já contrataram Produtora W antes (concorrente identificado)
✅ Ainda têm R$ 2.1M disponível (não gastaram tudo)
✅ Histórico de contratos de R$ 200-300k (nossa faixa!)

### PASSO 4: Benchmarking Entre Cidades

**CRIAR TABELA COMPARATIVA**:

| Prefeitura | População | Orçamento Cultura Total | Orçamento Eventos | Per Capita | Status |
|------------|-----------|-------------------------|-------------------|------------|--------|
| Caldas Novas | 100k | R$ 2.5M | R$ 1.2M | R$ 12/hab | ✅ Alto |
| Cidade B | 80k | R$ 800k | R$ 400k | R$ 5/hab | ⚠️ Médio |
| Cidade C | 120k | R$ 1.5M | R$ 600k | R$ 5/hab | ⚠️ Médio |

**INSIGHTS**:
- Caldas Novas gasta MUITO mais per capita (R$ 12 vs. R$ 5)
- Cidade B e C estão ABAIXO da média → Potencial de crescimento se mostrarmos ROI
- Focar em cidades com budget alto E disponibilidade de recursos

### PASSO 5: Timing Perfeito (Ciclo Orçamentário)

**ENTENDER O CICLO**:

```
JAN-MAR: Execução do orçamento aprovado (gastar dinheiro do ano)
ABR-JUN: Planejamento para ano seguinte (definir prioridades)
JUL-SET: Elaboração da LOA (definir valores)
OUT-DEZ: Aprovação da LOA (câmara vota)
```

**ESTRATÉGIA DE TIMING**:

**JAN-MAR**: 
- Prospectar para eventos de curto prazo (3-6 meses)
- Budget já aprovado, dinheiro disponível
- Foco: Executar logo (use "orçamento vai expirar")

**ABR-JUN**:
- Influenciar planejamento para ano seguinte
- Apresentar cases de ROI
- Objetivo: Entrar na lista de prioridades

**JUL-SET**:
- Participar de audiências públicas (se possível)
- Mostrar viabilidade de eventos grandes
- Fazer lobbying técnico (não político!)

**OUT-DEZ**:
- Aguardar aprovação
- Assim que LOA for aprovada, ATACAR (ser o primeiro)

### PASSO 6: Descobrir Fornecedores Anteriores

**NO PORTAL DA TRANSPARÊNCIA**:
```
Contratos > Buscar por "eventos" ou "shows" ou "estrutura"
→ Ver empresas contratadas
→ Valores pagos
→ Vigência do contrato
```

**ANÁLISE COMPETITIVA**:
- Quem eles contrataram antes?
- Quanto pagaram?
- Contrato único ou recorrente?
- Escopo (só artista? Estrutura completa?)

**EXEMPLO**:
```
Prefeitura de [Cidade] contratou:
- Produtora ABC: R$ 180k (2024)
- Produtora ABC: R$ 200k (2025)
- Tendência: Aumento de 11%

INSIGHTS:
✅ Há relação de confiança (2 anos consecutivos)
⚠️ Mas estão pagando mais (insatisfação com custo?)
🎯 Ângulo: "Mesma qualidade, custo otimizado"
```

---

## Workflow 7.3: Licitação & Edital Monitoring

**Quando usar**: "Buscar licitações abertas", "Editais de eventos", "Oportunidades públicas"

### FONTES DE LICITAÇÕES

**1. Diário Oficial**:
- Diário Oficial da União (DOU): in.gov.br
- Diário Oficial do Estado (Goiás): diariooficial.go.gov.br
- Diários Oficiais Municipais (cada cidade tem o seu)

**2. Portais de Compras**:
- ComprasNet (federal): comprasnet.gov.br
- Licitações-e (estadual/municipal): licitacoes-e.com.br
- Portal Nacional de Contratações Públicas: pncp.gov.br

**3. Sites de Agregadores**:
- Licita Já: licitaja.com.br
- Portal de Licitações: portaldaelicitacao.com.br
- (Muitos são pagos, mas têm trials)

### PASSO 1: Configurar Busca Estratégica

**PALAVRAS-CHAVE PARA ALERTAS**:
```
- "contratação artista"
- "produção evento"
- "estrutura palco"
- "shows" + "licitação"
- "evento cultural"
- "festa" + "edital"
- "réveillon" + "pregão"
- "aniversário cidade" + "contratação"
```

**FILTROS**:
- Região: Goiás, Tocantins, Mato Grosso, Distrito Federal
- Modalidade: Pregão Eletrônico, Tomada de Preços, Inexigibilidade
- Valor estimado: > R$ 50k (abaixo disso pode não valer esforço)

### PASSO 2: Análise Rápida do Edital

Quando encontrar licitação relevante, extrair:

**INFORMAÇÕES CRÍTICAS**:
- ✅ **Objeto**: O que estão contratando exatamente?
- ✅ **Valor estimado**: Quanto têm de budget?
- ✅ **Prazo de entrega**: Quando é o evento?
- ✅ **Critério de julgamento**: Menor preço? Técnica + preço?
- ✅ **Exigências técnicas**: Certificações, atestados necessários?
- ✅ **Prazo de proposta**: Até quando enviar?

**RED FLAGS** (quando NÃO vale a pena):
- ❌ Edital sob medida para concorrente (exigências muito específicas)
- ❌ Prazo muito curto (< 5 dias para preparar proposta complexa)
- ❌ Valor muito baixo (inexequível)
- ❌ Região muito distante (logística inviável)

**GREEN FLAGS** (oportunidades quentes):
- ✅ Edital genérico (qualquer empresa pode competir)
- ✅ Valor alto (R$ 200k+)
- ✅ Prazo adequado (15+ dias para preparar)
- ✅ Critério técnico (podemos nos diferenciar por qualidade)

### PASSO 3: Decisão de Participar

**CHECKLIST**:

1. **Fit com nosso serviço?** 
   - Sim: Shows, estrutura, produção
   - Não: Outros tipos de evento que não dominamos

2. **Temos capacidade de entrega?**
   - Data do evento compatível com nossa agenda?
   - Estrutura disponível?
   - Artistas no nosso network?

3. **Margem de lucro viável?**
   - Valor estimado cobre custos + margem?
   - Ou é apenas para "entrar na prefeitura"?

4. **Chance real de ganhar?**
   - Temos atestados/certificações exigidas?
   - Conhecemos a prefeitura? (relacionamento ajuda)
   - Concorrente tem preferência? (processo viciado?)

**ESTRATÉGIA DE DECISÃO**:

```
PARTICIPAR SE:
- Fit 100% com nosso core business
- Margem > 20%
- Chance de ganhar > 30%
- OU evento estratégico (referência, primeira vez na cidade)

DECLINAR SE:
- Edital sob medida para concorrente
- Margem < 10%
- Exigências impossíveis de cumprir
- Custo de preparar proposta > valor esperado
```

### PASSO 4: Preparação de Proposta Vencedora

**ELEMENTOS DE PROPOSTA COMPETITIVA**:

**1. Proposta Técnica**:
- Metodologia de execução (passo a passo do evento)
- Equipe técnica (currículos)
- Equipamentos (fotos, especificações)
- Cronograma detalhado
- Plano de contingência (o que fazer se X der errado)

**2. Proposta Comercial**:
- Planilha de custos detalhada
- Não ser o MAIS BARATO (suspeito)
- Nem o MAIS CARO (inviável)
- Estar na MÉDIA ou ligeiramente acima (justificado por qualidade)

**3. Diferenciais**:
- Atestados de eventos similares
- Fotos/vídeos de trabalhos anteriores
- Certificações técnicas
- Seguros (responsabilidade civil)
- Garantias (o que cobrimos se algo falhar)

**4. Compliance**:
- Documentação legal em ordem (certidões negativas, licenças)
- Proposta formatada exatamente como exigem
- TODOS os anexos obrigatórios
- Enviada antes do prazo

**ERRO FATAL**: Esquecer um documento → Desclassificação!

### PASSO 5: Pós-Licitação

**SE GANHAR**:
- ✅ Formalizar contrato rapidamente
- ✅ Executar com EXCELÊNCIA (virar fornecedor recorrente)
- ✅ Documentar tudo (fotos, vídeos, depoimentos)
- ✅ Pedir avaliação formal ao final

**SE PERDER**:
- 📊 Pedir cópia da proposta vencedora (LAI permite!)
- 🔍 Analisar: Por que perdemos? (Preço? Técnica?)
- 📝 Ajustar para próxima vez
- 🤝 Manter contato com a prefeitura (futuras oportunidades)

**SE HOUVER IRREGULARIDADE**:
- Empresa vencedora não tem capacidade técnica? → Impugnação
- Processo viciado? → Representação ao TCE (Tribunal de Contas do Estado)
- (Usar com cuidado - pode queimar relacionamento)

---

## Workflow 7.4: Inexigibilidade & Dispensa

**CONCEITO**: Nem tudo é licitação! Há brechas legais.

### INEXIGIBILIDADE (Art. 25, Lei 8.666)

Quando NÃO é obrigatório licitar:

**Artista Exclusivo**:
- Se artista tem exclusividade com a Solir
- Prefeitura quer AQUELE artista específico
- Contratação direta (sem licitação)

**Como usar**:
1. Ter contrato de exclusividade com artistas regionais
2. Quando prefeitura pedir "queremos artista X"
3. Mostrar que só a Solir tem acesso a ele
4. Contratação direta via inexigibilidade

### DISPENSA (Art. 24, Lei 8.666)

**Valor baixo** (até R$ 17.600 em 2024):
- Para pequenos eventos
- Processo simplificado
- Cotação com 3 empresas

**Emergência**:
- Evento confirmado de última hora
- Não há tempo para licitar
- Contratação emergencial

**Como usar**:
- Monitorar eventos de última hora (cancelamentos, imprevistos)
- Estar pronto para proposta em 24-48h
- Relacionamento com secretaria facilita (eles lembram de você)

---

## FERRAMENTAS & AUTOMAÇÃO

### ALERTAS AUTOMÁTICOS (Configurar):

**Google Alerts**:
```
"licitação" + "evento" + "Goiás"
"edital" + "show" + [cidade]
"pregão" + "artista"
```

**Newsletter de Licitações**:
- ComprasNet: Cadastrar para receber emails
- Portais estaduais: Alertas por categoria

**Checagem Manual** (Semanal):
- SEG: Diário Oficial de Goiás
- QUA: Portais de compras estaduais
- SEX: Agregadores (Licita Já, etc.)

### PLANILHA DE TRACKING

| Data | Prefeitura | Objeto | Valor | Prazo | Status | Nossa Decisão | Resultado |
|------|------------|--------|-------|-------|--------|---------------|-----------|
| 15/03 | Caldas Novas | Réveillon | R$ 450k | 30/03 | Aberto | ✅ Participar | - |
| 18/03 | Cidade X | Festa Junina | R$ 80k | 25/03 | Aberto | ❌ Valor baixo | - |
| 20/03 | Cidade Y | Show | R$ 300k | 22/03 | Aberto | ❌ Prazo curto | - |

---

## CASO DE USO COMPLETO

**CENÁRIO**: Encontrar oportunidades em editais públicos de Goiás

**ROTINA SEMANAL**:

**Segunda-feira** (30 min):
1. Checar Diário Oficial de Goiás
2. Buscar por "licitação" + "evento/show/artista"
3. Listar oportunidades encontradas

**Quarta-feira** (45 min):
1. Analisar editais listados
2. Aplicar checklist de decisão
3. Baixar editais dos que vamos participar

**Quinta-feira** (3-4h por edital):
1. Preparar proposta técnica
2. Calcular proposta comercial
3. Reunir documentação

**Prazo limite** (1 dia antes):
1. Revisar proposta
2. Checar TODOS os anexos
3. Enviar via sistema

**Resultado esperado**:
- 2-3 editais relevantes/mês
- Taxa de sucesso: 20-30% (1 a cada 3-5)
- 1-2 contratos públicos fechados/trimestre

---

## INTEGRAÇÃO COM SKILL PRINCIPAL

Este módulo alimenta:
- **Workflow 1.1 (Market Intelligence)**: Orçamento público = tamanho do mercado
- **Workflow 2.1 (ICP)**: Prefeituras com budget alto = ICP Tier 1
- **Workflow 5 (Proposta Comercial)**: Saber budget = precificar certo
- **Trigger Events**: Edital aberto = oportunidade quente AGORA

Portal da Transparência + Licitações = GOLD MINE para quem vende para governo! 🏆
