# MÓDULO ADICIONAL: CRM INTEGRATION & AUTOMATION

## Workflow 7.5: Pipeline Automation (Do Lead ao Cliente)

**Quando usar**: "Automatizar prospecção", "Integrar com CRM", "Criar sistema de follow-up"

### CONCEITO: SYSTEMS > HUSTLE

Prospecção manual funciona. Prospecção AUTOMATIZADA escala 10x.

---

## PARTE 1: CRM SETUP (Sistema de Gestão)

### Opção A: Google Sheets (GRATUITO - Começar Aqui)

**VANTAGENS**:
- ✅ Grátis
- ✅ Fácil de usar
- ✅ Compartilhável com equipe
- ✅ Integrável com scripts (Google Apps Script)

**ESTRUTURA DE PLANILHA CRM**:

**ABA 1: LEADS (Pipeline)**

| ID | Empresa | Tipo | Cidade | Decisor | Cargo | Email | Telefone | LinkedIn | Score | Status | Próxima Ação | Data | Responsável |
|----|---------|------|--------|---------|-------|-------|----------|----------|-------|--------|--------------|------|-------------|
| 001 | Pref. Caldas | Prefeitura | Caldas Novas | Maria Silva | Sec. Cultura | email@ | (62)9999 | link | 85 | Proposta Enviada | Aguardar resposta | 25/03 | Victor |
| 002 | Sind. Rural RV | Sindicato | Rio Verde | João Costa | Presidente | email@ | (64)8888 | link | 72 | Reunião Agendada | Call 27/03 10h | 27/03 | Victor |

**Colunas Essenciais**:
- **Score**: 0-100 (ICP fit + engagement)
- **Status**: New Lead → Contacted → Qualified → Proposal → Negotiation → Won/Lost
- **Próxima Ação**: O QUE fazer (não esquecer follow-ups!)
- **Data**: QUANDO fazer (urgência)

**ABA 2: HISTÓRICO DE INTERAÇÕES**

| Lead ID | Data | Canal | Tipo | Notas | Próximo Follow-up |
|---------|------|-------|------|-------|-------------------|
| 001 | 20/03 | Email | Outreach inicial | Enviado intro email | 23/03 |
| 001 | 23/03 | Email | Follow-up 1 | Sem resposta ainda | 26/03 |
| 001 | 25/03 | LinkedIn | Mensagem | Aceitou conexão, respondeu interesse | Agendar call |

**ABA 3: TEMPLATES**

Guardar seus templates de email/mensagem com performance:

| Template | Canal | Taxa Resposta | Usado (vezes) | Conversão | Status |
|----------|-------|---------------|---------------|-----------|--------|
| Prefeitura - Intro v1 | Email | 12% | 50 | 3 reuniões | Ativo |
| Sindicato - WhatsApp v2 | WhatsApp | 28% | 35 | 8 reuniões | **Winner** |

**ABA 4: MÉTRICAS**

Dashboard simples:

```
Total Leads: 150
- New: 40
- Contacted: 60
- Qualified: 30
- Proposal: 15
- Negotiation: 3
- Won: 2

Taxa de Conversão: 1.3% (2 wins / 150 leads)
Valor Total Pipeline: R$ 450k
Deals Fechados (mês): R$ 80k
```

---

### Opção B: CRM Profissional (PAGO - Escalar Depois)

**FERRAMENTAS RECOMENDADAS**:

**1. Pipedrive** (R$ 50-150/mês):
- ✅ Visual (kanban de pipeline)
- ✅ Automações (emails automáticos)
- ✅ Integrações (Gmail, WhatsApp)
- ✅ Relatórios

**2. HubSpot CRM** (Grátis até 1M contatos!):
- ✅ Gratuito
- ✅ Email tracking (sabe quando abriram)
- ✅ Sequences (emails automáticos)
- ✅ Landing pages (se quiser site)

**3. RD Station CRM** (Brasil, R$ 60-200/mês):
- ✅ Interface em PT-BR
- ✅ Suporte local
- ✅ Integrações brasileiras (WhatsApp Business)

**CONFIGURAÇÃO BÁSICA**:

1. **Campos Customizados**:
   - ICP Tier (1, 2, 3)
   - Tipo de Cliente (Prefeitura, Sindicato, Empresa, Festival)
   - Orçamento Estimado
   - Data do Evento
   - Concorrente Atual (se houver)

2. **Pipeline Stages**:
   ```
   New Lead → Contacted → Qualified → Meeting Scheduled → 
   Proposal Sent → Negotiation → Won / Lost
   ```

3. **Automações**:
   - Lead novo → Email de boas-vindas automático
   - 3 dias sem atividade → Lembrete de follow-up
   - Proposta enviada → Tarefa "ligar em 2 dias"
   - Deal won → Email de agradecimento + pedir referências

---

## PARTE 2: AUTOMATION WORKFLOWS

### Workflow Auto 1: Lead Capture (Captura Automática)

**OBJETIVO**: Leads entram no CRM automaticamente.

**FONTES**:

**A) Formulário no Site**:
```html
Página: solirproducoes.com.br/contato
Campos: Nome, Email, Telefone, Tipo de Evento, Data, Cidade
Integração: Formulário → Zapier → Google Sheets/CRM
```

**B) Email de Prospecção**:
```
Quando prospect responde email
→ Tag no Gmail "PROSPECT RESPONDEU"
→ Zapier pega email taggeado
→ Adiciona ao CRM automaticamente
→ Notifica você no Slack/Telegram
```

**C) LinkedIn**:
```
Quando alguém aceita conexão
→ Manualmente adicionar ao CRM (ainda não tem automação nativa)
→ Ou usar ferramenta como Phantombuster (scraping)
```

### Workflow Auto 2: Lead Enrichment (Enriquecimento)

**OBJETIVO**: Adicionar dados automaticamente.

**PROCESSO**:
```
Lead entra com apenas Nome + Email
↓
Ferramenta de enriquecimento busca:
- Cargo (LinkedIn)
- Empresa (domínio do email)
- Telefone (Truecaller, Dados públicos)
- Localização (IP, perfil público)
↓
CRM atualizado automaticamente
```

**FERRAMENTAS**:
- Clearbit (caro, mas bom)
- Hunter.io (emails + enriquecimento básico)
- FullContact (dados de contato)
- Scrapers customizados (Python scripts)

### Workflow Auto 3: Sequências de Follow-Up

**OBJETIVO**: Não esquecer de ninguém.

**EXEMPLO - SEQUÊNCIA PREFEITURA (7 touchpoints em 15 dias)**:

```
DIA 0: Lead qualificado entra no CRM
  → Status: "New Lead"

DIA 1: Email #1 enviado automaticamente
  → Template: "Intro Prefeitura v3"
  → Status muda para: "Contacted"

DIA 3 (se não respondeu): Email #2 automático
  → Template: "Follow-up Case Study"

DIA 5 (se não respondeu): Tarefa manual criada
  → "Ligar para [Nome]"

DIA 7 (se ligou, sem sucesso): LinkedIn message automática
  → "Vi que não conseguimos conectar por email..."

DIA 10 (se não respondeu): Email #3 (breakup)
  → "Arquivando este contato?"

DIA 15: Se ainda sem resposta
  → Status muda para: "Cold - Nurture Later"
  → Entra em lista de re-engajamento (60 dias depois)
```

**FERRAMENTAS**:
- HubSpot Sequences (nativo)
- Lemlist (especialista em cold email)
- Reply.io (multi-channel: email + LinkedIn)
- Woodpecker (cold email)

### Workflow Auto 4: Task Management (Não Cair Nada)

**PROBLEMA**: Esquecer de follow-ups mata deals.

**SOLUÇÃO**: Automação de lembretes.

**REGRAS**:
```
SE lead está em "Contacted" por > 3 dias SEM atividade
→ CRIAR tarefa "Follow-up com [Nome]"
→ Atribuir para: Victor
→ Prazo: Hoje

SE lead está em "Proposal Sent" por > 5 dias SEM resposta
→ CRIAR tarefa "Ligar para [Nome] sobre proposta"
→ Prioridade: Alta

SE reunião agendada
→ CRIAR tarefa 1 dia antes: "Preparar briefing para call com [Nome]"

SE deal fechado (Won)
→ CRIAR tarefa: "Pedir referências e testimonial"
→ CRIAR tarefa (30 dias depois): "Check-in pós-evento"
```

### Workflow Auto 5: Reporting (Saber Onde Está)

**OBJETIVO**: Dashboard atualizado em tempo real.

**MÉTRICAS AUTOMÁTICAS**:
```
Diariamente às 8h:
→ Email com resumo:
  - Leads novos (últimas 24h)
  - Reuniões agendadas (próximos 7 dias)
  - Propostas pendentes
  - Deals próximos de fechar
  - Follow-ups atrasados (RED FLAG!)
```

**DASHBOARD (Google Data Studio ou dentro do CRM)**:
- Gráfico: Leads por Status (funil visual)
- Gráfico: Conversão por Fonte (qual canal traz mais)
- Gráfico: Tempo médio em cada stage
- KPI: Taxa de conversão total
- KPI: Valor médio de deal
- KPI: Forecast (projeção de revenue)

---

## PARTE 3: INTEGRATIONS (Conectar Tudo)

### Integração 1: Email (Gmail) ↔ CRM

**O QUE CONECTAR**:
- Emails enviados aparecem no histórico do lead
- Emails recebidos criam atividade automática
- Tracking: Saber quando abriram, clicaram

**COMO**:
- HubSpot/Pipedrive têm plugins para Gmail
- Emails enviados pelo CRM são tracked automaticamente

### Integração 2: WhatsApp ↔ CRM

**O QUE CONECTAR**:
- Mensagens do WhatsApp registradas no CRM
- Não perder histórico de conversas

**COMO** (semi-manual):
- WhatsApp Web + Extension do Chrome para copiar conversas
- Ou: WhatsApp Business API (caro, mas automatiza)

### Integração 3: Calendar ↔ CRM

**O QUE CONECTAR**:
- Reunião agendada → Adiciona ao Google Calendar
- Lembretes automáticos 1h antes

**COMO**:
- Google Calendar Sync (nativo em HubSpot/Pipedrive)
- Ou: Link de agendamento (Calendly) integrado ao CRM

### Integração 4: LinkedIn ↔ CRM

**O QUE CONECTAR**:
- Conexões novas viram leads
- Mensagens do LinkedIn registradas

**COMO** (limitado):
- Phantombuster (scraping - cuidado com ToS do LinkedIn)
- Dux-Soup (extensão Chrome)
- Ou: Manual (ainda é o mais seguro)

---

## PARTE 4: AUTOMAÇÃO AVANÇADA (Zapier/Make)

### Exemplo 1: "Prospect Respondeu Email"

**TRIGGER**: Email recebido com tag "Prospect"

**AÇÕES**:
1. Extrair dados do email (nome, conteúdo)
2. Atualizar status no CRM para "Engaged"
3. Criar tarefa "Responder [Nome] hoje"
4. Enviar notificação Telegram: "🔥 Lead quente! [Nome] respondeu"
5. Adicionar +10 pontos no Lead Score

### Exemplo 2: "Novo Edital Publicado"

**TRIGGER**: Google Alert de licitação chega no email

**AÇÕES**:
1. Parsear email (extrair cidade, valor, objeto)
2. Adicionar linha na planilha "Editais"
3. Enviar notificação WhatsApp: "📄 Novo edital em [Cidade] - R$ [Valor]"
4. Se valor > R$ 200k: Criar lead automático no CRM

### Exemplo 3: "Follow-up Automático Inteligente"

**TRIGGER**: 3 dias após enviar email, se não houve resposta

**AÇÕES**:
1. Checar no CRM: Lead respondeu por outro canal?
2. Se não: Enviar follow-up email automaticamente
3. Se sim: Marcar como "não enviar auto follow-up"

---

## PARTE 5: BEST PRACTICES

### 1. Data Hygiene (Limpar Dados)

**PROBLEMA**: CRM vira bagunça com tempo.

**SOLUÇÃO**:
- Semanalmente: Revisar leads duplicados
- Mensalmente: Limpar leads "dead" (> 6 meses sem atividade)
- Sempre: Padronizar formatação (capitalização, nomes completos)

### 2. Pipeline Discipline (Disciplina)

**REGRA DE OURO**: 
```
NUNCA deixe lead sem "Próxima Ação" definida.
```

**CHECKLIST ao mover lead de stage**:
- [ ] Próxima ação está clara?
- [ ] Data está definida?
- [ ] Responsável atribuído?
- [ ] Notas atualizadas?

### 3. Weekly Review (Revisão Semanal)

**TODA SEXTA 17h** (30 min):
1. Ver pipeline: Quais deals estão travados?
2. Follow-ups atrasados: Colocar em dia
3. Leads frios: Mover para nurture ou descartar
4. Métricas: Estamos no caminho para meta?

### 4. Feedback Loop (Aprender)

**QUANDO GANHAR UM DEAL**:
- Registrar: O que funcionou?
- Qual mensagem gerou resposta?
- Qual argumento fechou?
- Replicar sucesso

**QUANDO PERDER**:
- Registrar: Por que perdemos?
- Preço? Timing? Relacionamento?
- Ajustar abordagem

---

## SETUP RÁPIDO (Próximos 7 Dias)

**DIA 1**: Criar Google Sheets CRM
- Abas: Leads, Histórico, Templates, Métricas
- Adicionar 10 leads atuais (testar estrutura)

**DIA 2**: Organizar Templates
- Compilar emails que funcionaram
- Salvar na aba Templates
- Versionar (v1, v2, v3)

**DIA 3**: Configurar Gmail
- Tags: "Prospect", "Cliente", "Proposta Enviada"
- Filtros automáticos
- Testar tracking (HubSpot plugin ou Mailtrack)

**DIA 4**: Primeiro Automação
- Zapier free tier (100 tasks/mês)
- Zap simples: Gmail tag → Google Sheets row

**DIA 5**: Definir Rotinas
- Segunda 9h: Adicionar leads novos
- Quarta 14h: Follow-ups
- Sexta 17h: Weekly review

**DIA 6**: Testar Sequência
- Escolher 5 leads frios
- Rodar sequência de 3 emails
- Medir taxa de resposta

**DIA 7**: Ajustar & Escalar
- O que funcionou? Fazer mais
- O que falhou? Corrigir
- Planejar semana 2

---

## ROI DA AUTOMAÇÃO

**ANTES (Manual)**:
- 2h/dia em follow-ups e admin
- 10-15 leads novos/semana
- Taxa de conversão: 1%
- 1-2 deals/mês

**DEPOIS (Automatizado)**:
- 30min/dia em admin (CRM faz resto)
- 1h30 liberadas para prospecção estratégica
- 25-30 leads novos/semana (mais tempo = mais prospecção)
- Taxa de conversão: 1.5% (menos leads caem)
- 3-4 deals/mês

**RESULTADO**: 2x mais deals com MENOS esforço! 🚀

---

## FERRAMENTAS STACK RECOMENDADO

**GRATUITO (Começar)**:
- Google Sheets (CRM)
- Gmail + Mailtrack (email tracking)
- Google Calendar
- Zapier Free (100 automações/mês)
- Notion (documentação)

**INTERMEDIÁRIO (R$ 100-200/mês)**:
- HubSpot CRM (grátis!) + Sales Hub (R$ 50/mês)
- Lemlist (R$ 150/mês - cold email)
- Calendly (R$ 30/mês - agendamento)

**AVANÇADO (R$ 500+/mês)**:
- Pipedrive (R$ 150/mês)
- Apollo.io (R$ 300/mês - enriquecimento + outreach)
- Clay (R$ 500/mês - automação heavy)
- Make.com (R$ 200/mês - Zapier on steroids)

**COMEÇAR GRÁTIS, ESCALAR CONFORME CRESCE!**

---

## INTEGRAÇÃO COM SKILL PRINCIPAL

Este módulo automatiza TODO o processo de Revenue Hunter:
- Market Intelligence → Leads entram no CRM automaticamente
- Lead Discovery → Enriquecimento automático
- Sequencing → Follow-ups nunca falham
- Metrics → Dashboard sempre atualizado

**Skill + CRM + Automação = MÁQUINA DE VENDAS IMPARÁVEL!** 💪
